--[[
/* Copyright (C) 2015 SAS Institute Inc. Cary, NC, USA */

/*!
\file    risk.lua

\brief   This file is to store the Risk library which has all the functions declared. 

\ingroup commonAnalytics

\author  SAS Institute Inc.

\date    2015

\details This file first creates class: FXQuote,
         then declare all the functions:  setFXQuoteGraph getFXQuoteGraph
                                          convertCompleteFXQuote, getOptimizedFXQuote, getBFSFXQuote,
                                          convertFXQuoteGraphToSPGraph, convertSPArrayToFXQuoteArray,
                                          convertSPMatrixToFXQuoteMatrix,updateLogFXRateFunctor,
                                          dropRedundantCurrencyPair,getBFSSingleFXQuote

*/

]]


local graph = require "luastl.graph"
local util = require "luastl.util"
local collection = require "luastl.collection"

local risk={}

--[[
/*!
\class    FXQuote

\function newFXQuote

\brief    Use graph to store FX Quote. For convention,
          FXQuoteGraph[QUOTE_CURRENCY][BASE_CURRENCY] = BASE_CURRENCY/QUOTE_CURRENCY
          eg, EUR/USD = 1.3620 = FXQuoteGraph[USD][EUR]
          means 1 EUR exchange to 1.3620 USD

\ingroup risk.lua

*/
]]

function risk.newFXQuote()

  local self = {
                FXQuoteGraph = {}
                }
                
  --forward define function
  --  public function
  local setFXQuoteGraph
  local getFXQuoteGraph
  local convertCompleteFXQuote
  local getOptimizedFXQuote
  local getBFSFXQuote
  -- private function
  local convertFXQuoteGraphToSPGraph
  local convertSPArrayToFXQuoteArray
  local convertSPMatrixToFXQuoteMatrix
  local updateLogFXRateFunctor
  local dropRedundantCurrencyPair
  local getBFSSingleFXQuote

--[[
/*!
\function dropRedundantCurrencyPair

\brief    Drop the currency quote with the same base currency and
          quote currency
          
 \param[in] FXGraph              input fx graph
 
\ingroup risk.lua

*/
]]

  dropRedundantCurrencyPair = function(FXGraph)
    
    local currency
    
    for currency in FXGraph.allVertexes() do
        
      FXGraph.setWeight(currency, currency, nil)
      
    end
  
    return FXGraph
    
  end  
  
--[[
/*!
\function convertFXQuoteGraphToSPGraph

\brief    Use -log function to transfer FX quote. Convert
          optimized quote problem into finding shortest path problem 
          in Graph theory 
          
 \param[in] FXGraph              input fx graph
 
\ingroup risk.lua

*/
]]

  convertFXQuoteGraphToSPGraph = function(FXGraph)
  
    local qFXQuoteGraph = graph.NewGraph()
    
    local base_currency, quote_currency, quote
    
    for base_currency, quote_currency, quote in FXGraph.allEdges() do
        
      qFXQuoteGraph.setWeight(base_currency, quote_currency, -1 * math.log(quote))
      
    end
  
    return qFXQuoteGraph
    
  end

--[[
/*!
\function convertSPGraphToFXQuoteGraph

\brief    Covert back to FX quote y = exp( -1 * x)
          
 \param[in] SPGraph              input shortest path graph
 
\ingroup risk.lua

*/
]]

  convertSPGraphToFXQuoteGraph = function(SPGraph)
  
    local qFXQuoteGraph = graph.NewGraph()
    
    local base_currency, quote_currency, weight
    
    for base_currency, quote_currency, weight in SPGraph.allEdges() do
        
      qFXQuoteGraph.setWeight(base_currency, quote_currency, math.exp( -1 * weight))
      
    end
  
    return qFXQuoteGraph
    
  end

--[[
/*!
\function convertSPArrayToFXQuoteArray

\brief    Covert back to FX quote y = exp( -1 * x)
          
 \param[in] shortest_path              input shortest path graph
 
\ingroup risk.lua

*/
]]


  convertSPArrayToFXQuoteArray = function(shortest_path)
  
    local vertex, weight, FXQuote
    
    FXQuote = {}
    
    for vertex, weight in pairs(shortest_path) do
    
      FXQuote[vertex] = math.exp( -1 * weight)
      
    end
    
    return FXQuote    
  
  end
  
--[[
/*!
\function convertSPMatrixToFXQuoteMatrix

\brief    Covert back to FX quote y = exp( -1 * x)
          
 \param[in] shortest_path_matrix              input shortest path matrix
 
\ingroup risk.lua

*/
]]

  convertSPMatrixToFXQuoteMatrix = function(shortest_path_matrix)
  
    local base_currency, shortest_path_array, FXQuote
    
    FXQuote = {}
    
    for base_currency, shortest_path_array in pairs(shortest_path_matrix) do
    
      FXQuote[base_currency] = convertSPArrayToFXQuoteArray(shortest_path_array)      
      
      
    end
    
    return FXQuote    
  
  end
  
--[[
/*!
\function setFXQuoteGraph

\brief    pass in FX quote graph
          
 \param[in] graph              input FX Quote graph
 
\ingroup risk.lua

*/
]]
  setFXQuoteGraph = function (graph)
    self.FXQuoteGraph = graph
  end

--[[
/*!
\function getFXQuoteGraph

\brief    pass in FX quote graph
          
 \param[in] SPGraph              input quote graph
 
\ingroup risk.lua

*/
]]

  getFXQuoteGraph = function()
    return self.FXQuoteGraph
  end
  
--[[
/*!
\function convertCompleteFXQuote

\brief    If bid/ask quote is nil, assuming there is no spread
          between bid/ask quote, take reciprocal to complete 
          FX quote graph
          
 \param[in] SPGraph              input Fx quote graph
 
\ingroup risk.lua

*/
]]
  convertCompleteFXQuote = function()
  
    local quote_currency, base_currency, quote, qFXQuoteGraph
    
    qFXQuoteGraph = util.deepCopy(self.FXQuoteGraph)
    
    for base_currency, quote_currency,  quote in qFXQuoteGraph.allEdges() do
      
      local reciprocal_quote = self.FXQuoteGraph.getWeight(quote_currency, base_currency)
      
      if  reciprocal_quote == nil then
      
        self.FXQuoteGraph.setWeight( quote_currency, base_currency, 1 / quote)
      
      end
    
    end
        
  end-- end of local convertCompleteFXQuote = function()

--[[
/*!
\function getOptimizedFXQuote

\brief    Use Bellman-Ford algorithm to look for optimized cross 
          FX quote
          
 \param[in] Base_Currency         base currency. If it is nil, perform
                                  all pairs shortest path algorithm to 
                                  get optimized FX quotes. 
 
 \param[in] rounding_error        Rounding error
 
 \param[out] flag                 boolean flag to indicate if FX arbitrage
                                  opportunities don't exist   
  
 \param[out] FX_Quotes_Graph      FX optimized quotes in graph
 
 \param[out] predecessorsSet      predecessors in a set of 1D table     
 
\ingroup risk.lua

*/
]]
  getOptimizedFXQuote = function (Base_Currency, rounding_error)

    local converted_FX_Graph = convertFXQuoteGraphToSPGraph(self.FXQuoteGraph)
    
    local flag, shortest_path, predecessors, predecessorsSet
    
    local optFXQuotesGraph, quote_currency, quote
      
    optFXQuotesGraph = graph.NewGraph()
    
    predecessorsSet = collection.NewSet()
    
    if Base_Currency == nil then
      -- Use all pairs shortest path 
      local shortest_path_Graph
      
      flag, shortest_path_Graph = converted_FX_Graph.FloydWarshallShortestPath(rounding_error)
      
      return flag, dropRedundantCurrencyPair(convertSPGraphToFXQuoteGraph(shortest_path_Graph)), nil
    
    else         
      -- Single source shortest path
      flag, shortest_path, predecessors = converted_FX_Graph.BellmanFordShortestPath(Base_Currency, rounding_error)
      
      -- convert -ln(FX quote) ==> FX quote
      local converted_shortest_path = convertSPArrayToFXQuoteArray(shortest_path)
      -- convert shortest_path 1D table into FX quote graph      
      for quote_currency, quote in pairs(converted_shortest_path) do
      
        optFXQuotesGraph.setWeight(Base_Currency, quote_currency, quote)
      
      end
      
      predecessorsSet.insert(Base_Currency, predecessors)      
          
    end -- end of else if Base_Currency == nil then
        
    return flag, dropRedundantCurrencyPair(optFXQuotesGraph), predecessorsSet
    
  end

--[[
/*!
\function updateLogFXRateFunctor

\brief    passed in as BFS functor
          
 \param[in] GraphMatrix              input graph matrix
 
 \param[in] vertex                   vertex

 \param[in] adj_vertex               adjusted vertex  
 
 \param[out] bfs_path                Breadth-First-Search path


\ingroup risk.lua

*/
]]
  updateLogFXRateFunctor = function(GraphMatrix, vertex, adj_vertex, bfs_path)
  
    assert(GraphMatrix[vertex][adj_vertex] ~= nil)
    
    assert(bfs_path[vertex] ~= nil)
    
    bfs_path[adj_vertex] = bfs_path[vertex] + GraphMatrix[vertex][adj_vertex]
    
  end
  
--[[
/*!
\function getBFSSingleFXQuote

\brief    Use breadth first search algorithm to find single
          source FX quote
          
 \param[in]  Base_Currency             base currency
 
 \param[out] converted_bfs_path        converted breadth first search path
 
 \param[out] predecessors              predecessor value
 
\ingroup risk.lua

*/
]]
  getBFSSingleFXQuote = function (Base_Currency, converted_FX_Graph)
    
    local bfs_path = {}
    
    -- initialize with quote 1 = Base_Currency/Base_Currency
    -- -1 * ln(Base_Currency/Base_Currency) = 0 
    bfs_path[Base_Currency] = 0
    
    local predecessors
    
    _, predecessors = converted_FX_Graph.BreadthFirstSearch(  Base_Currency, 
                                                              false,
                                                              updateLogFXRateFunctor,
                                                              bfs_path)
    -- convert shortest_path 1D table into FX quote graph
    local quote_currency, quote      
      
    -- convert -ln(FX quote) ==> FX quote
    local converted_bfs_path = convertSPArrayToFXQuoteArray(bfs_path)      
         
    return converted_bfs_path, predecessors
    
  end

--[[
/*!
\function getBFSFXQuote

\brief    Use breadth first search algorithm to find single
          source FX quote
          
 \param[in] Base_Currency              base currency
                                       if Base_Currency is nil,
                                        then use BFS to find all currency
                                       quotes

 \param[out] Converted FX quote        converted FX quote in graph

 \param[out] predecessorSet            predecessors in a set of 1D table
 
\ingroup risk.lua

*/
]]

  getBFSFXQuote = function(Base_Currency)
    
    -- convert FX quote graph into new graph with weight = -1 * log(BASE/QUOTE)
    local converted_FX_graph = convertFXQuoteGraphToSPGraph(self.FXQuoteGraph)
    
    local optFXQuotesGraph, quote_currency, quote, bfs_path, predecessors, predecessorSet
    
    optFXQuotesGraph = graph.NewGraph()
    
    predecessorSet = collection.NewSet()
   
    if Base_Currency == nil then
      -- loop through all currency
      local currency
      
      for currency in self.FXQuoteGraph.allVertexes() do
      
        bfs_path, predecessors = getBFSSingleFXQuote(currency, converted_FX_graph)     
             
        for quote_currency, quote in pairs(bfs_path) do
      
          optFXQuotesGraph.setWeight(currency, quote_currency, quote)
        
        end -- end of for quote_currency, quote in pairs(bfs_path) do
        
        predecessorSet.insert(currency, predecessors)
      
      end -- end of or base_currency in self.FXQuoteGraph.allVertexes() do
     
    else
    
      -- convert shortest_path 1D table into FX quote graph
      bfs_path, predecessors = getBFSSingleFXQuote(Base_Currency, converted_FX_graph)     
             
      for quote_currency, quote in pairs(bfs_path) do
      
        optFXQuotesGraph.setWeight(Base_Currency, quote_currency, quote)
        
      end 
    
      predecessorSet.insert(Base_Currency, predecessors)
      
    end -- end of else if Base_Currency is nil then
    
    return dropRedundantCurrencyPair(optFXQuotesGraph), predecessorSet
    
  end 
  
--[[
/*!
\brief    Publish member function

*/
]]

  return {
          setFXQuoteGraph = setFXQuoteGraph,
          getFXQuoteGraph = getFXQuoteGraph,
          convertCompleteFXQuote = convertCompleteFXQuote,
          getOptimizedFXQuote = getOptimizedFXQuote,
          getBFSFXQuote = getBFSFXQuote
          }
          
end -- end of function risk.newFXQuote()

return risk  
