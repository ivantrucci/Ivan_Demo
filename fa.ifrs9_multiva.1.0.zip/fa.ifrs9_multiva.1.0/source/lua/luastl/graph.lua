--[[
/* Copyright (C) 2015 SAS Institute Inc. Cary, NC, USA */

/*!
\file    graph.lua

\brief   This file is to store the Graph library which has all the functions declared. 

\ingroup commonAnalytics

\author  SAS Institute Inc.

\date    2015

\details This file first creates class: graph,
         then declare all the functions:  NewGraph getWeight setWeight allEdges allConnectedVertexes
                                          allAdjacentVertexes allVertexes getVertexSet getConnectedVertexSet
                                          setGraphMatrix DijkstraShortestPath BellmanFordShortestPath
                                          getWeight setWeight BreadthFirstSearch Extend_shortest_paths
                                          AllPairsShortestPath FloydWarshallShortestPath
                                          checkAllPairsNegativeCycles


*/

]]

local graph={}

local util = require "luastl.util"
local collection = require "luastl.collection"

function graph.NewGraph()

  local self = {           
                GraphMatrix = {}
               }
               
  --forward define function
  local allEdges
  local allAdjacentVertexes
  local allConnectedVertexes
  local allVertexes
  local getVertexSet
  local getConnectedVertexSet
  local setGraphMatrix
  local DijkstraShortestPath
  local BellmanFordShortestPath
  local getWeight
  local setWeight
  local BreadthFirstSearch
  local Extend_shortest_paths
  local AllPairsShortestPath
  local FloydWarshallShortestPath
  local checkAllPairsNegativeCycles
  
--[[
/*!
\function getWeight

\brief    get weight between two vertex
          
 \param[in] startingVertex              starting vertex
 
 \param[in] endVertex                   ending vertex
 
\ingroup graph.lua 

*/
]]
  getWeight = function(startingVertex, endVertex)
  
      if self.GraphMatrix[startingVertex] == nil then 
        
        return nil
      
      else
      
        return self.GraphMatrix[startingVertex][endVertex]
        
      end
      
  end
  
--[[
/*!
\function setWeight

\brief    set weight between two vertex
          
 \param[in] startingVertex              starting vertex
 
 \param[in] endVertex                   ending vertex
 
 \param[in] weight                      weight value
 
\ingroup graph.lua 

*/
]]
  setWeight = function(startingVertex, endVertex, weight)
  
      if self.GraphMatrix == nil then
      
        self.GraphMatrix = {}
      
      end
  
      if self.GraphMatrix[startingVertex] == nil then
        
        self.GraphMatrix[startingVertex] = {}
      
      end
      
      self.GraphMatrix[startingVertex][endVertex] = weight
      
  end

--[[
/*!
\function allEdges

\brief    create iterators of edges in graph
          
\ingroup graph.lua 

*/
]]
  allEdges = function()
  
    return coroutine.wrap(

      function()
        
        local vertexSet = getVertexSet()
        
        local adjVertex, vertex
        
        for vertex in vertexSet.allElements() do
        
          if self.GraphMatrix[vertex] ~= nil then
            
            --loop through adjacent vertex
            for adjVertex in allAdjacentVertexes(vertex) do
            
              coroutine.yield(vertex, adjVertex, self.GraphMatrix[vertex][adjVertex])      
            
            end -- end of for adjVertex in allAdjacentVertexes(vertex) do
            
          end -- end of if self.GraphMatrix[vertex] ~= nil then
          
        end -- end of for vertex in vertexSet.allElements() do
        
      end)
    
  end  

--[[
/*!
\function allConnectedVertexes

\brief    create iterators of connected vertex in graph
          
 \param[in] Starting_Vertex              starting vertex
 
\ingroup graph.lua 

*/
]]
  allConnectedVertexes = function(Starting_Vertex)
  
    return coroutine.wrap(

      function()
        
        local vertexSet = getConnectedVertexSet(Starting_Vertex)
        
        local vertex
        
        for vertex in vertexSet.allElements() do
          
          coroutine.yield(vertex)
          
        end -- end of for vertex in vertexSet.allElements() do
        
      end)
    
  end
  
--[[
/*!
\function allAdjacentVertexes

\brief    create iterators of adjacent vertex set
          
 \param[in] Vertex                      starting vertex
 
\ingroup graph.lua 

*/
]]
  --adjacent vertex iterator
  allAdjacentVertexes = function(Vertex)
  
    return coroutine.wrap(
      function()
        local adj_vertex
        for adj_vertex in pairs(self.GraphMatrix[Vertex]) do
          coroutine.yield(adj_vertex)
        end
      end)
  
  end

--[[
/*!
\function allVertexes

\brief    create iterators of vertex 
 
\ingroup graph.lua 

*/
]]
  allVertexes = function()
  
    return coroutine.wrap(
      function()
        local vertexSet = getVertexSet()
        local vertex
        for vertex in vertexSet.allElements() do
          coroutine.yield(vertex)
        end
      end)
  
  end

--[[
/*!
\function getVertexSet

\brief    return a set of whole vertex set in GraphMatrix 
          
 \param[in] flag             default value of vertex attribute
 
\ingroup graph.lua 

*/
]]

  -- return a set of vertexes in graph
  getVertexSet = function(flag)
  
    flag = flag or false
    
    local vertex_set = collection.NewSet()
    local vertex_i, vertex_j, array
  
    for vertex_i, array in pairs(self.GraphMatrix) do
      
      vertex_set.insert(vertex_i, flag)
      
      for vertex_j, _ in pairs(array)do
        vertex_set.insert(vertex_j, flag)
      end
    
    end
    return vertex_set
  
  end
  
--[[
/*!
\function getConnectedVertexSet

\brief    return a set of connected vertex in GraphMatrix 
          
 \param[in] Staring_Vertex              starting vertex 
 
 \param[in] flag                        default value of vertex attribute
 
\ingroup graph.lua 

*/
]]
  -- return a set of connected vertex in graph
  -- using breadth first in graph
  getConnectedVertexSet = function (Starting_Vertex, flag)
  
    return BreadthFirstSearch(Starting_Vertex, flag, nil, nil)
    
  end

  setGraphMatrix = function (GraphMatrix)
    self.GraphMatrix = GraphMatrix
  end
  
  local getGraphMatrix = function()
    return self.GraphMatrix
  end

--[[
/*!
\function DijkstraShortestPath

\brief    single source non-negative weighted shortest path
          Dijkstra's algorithm 
          
 \param[in] Starting_Vertex             single source
 
 \param[in] shortest_path               shortest path array
 
\ingroup graph.lua 

*/
]]
  DijkstraShortestPath = function(Starting_Vertex)
  
    local -- min priority queue that stores shortest path as priority 
          -- and vertex as its key
          sMinPQueue = collection.newMinPriorityQueue(), 
          -- connected vertex set
          connectedVertexSet,
          -- shortest_path from Starting_Vertex
          shortest_path        
  
    shortest_path = {}
    
    -- initialize vertexSet with connected vertex set
    shortest_path[Starting_Vertex] = 0 
    sMinPQueue.insert(Starting_Vertex, shortest_path[Starting_Vertex])
    
    connectedVertexSet = getConnectedVertexSet(Starting_Vertex)
    
    local connectedVertex
    
    for connectedVertex in connectedVertexSet.allElements() do
    
      sMinPQueue.insert(connectedVertex, nil)
      
    end
    
    
    while not sMinPQueue.isEmpty() do
    
      local vertexU, weight, altWeight, adjVertexOfU
      
      vertexU, weight = sMinPQueue.extractMin()
      
      -- iterate adjacent vertex of vertex u
      for adjVertexOfU in allAdjacentVertexes(vertexU) do
        
        altWeight = weight + getWeight(vertexU, adjVertexOfU)
        
        if shortest_path[adjVertexOfU] == nil then
        
          shortest_path[adjVertexOfU] = altWeight
          
          sMinPQueue.decreasePriority(adjVertexOfU, shortest_path[adjVertexOfU])
          
        else
        
          if shortest_path[adjVertexOfU] > altWeight then
          
            shortest_path[adjVertexOfU] = altWeight
          
            sMinPQueue.decreasePriority(adjVertexOfU, shortest_path[adjVertexOfU])
          
          end
        
        end -- end of else if shortest_path[adjVertexOfU] == nil then        
        
      end -- end of for adjVertexOfU in allAdjacentVertexes(vertexU) do      
    
    end -- end of while not sMinPQueue.isEmpty() do
    
    return shortest_path 
    
  end -- end of local DijkstraShortestPath = function(Starting_Vertex)

--[[
/*!
\function BellmanFordShortestPath

\brief    single source weighted shortest path
          Bellman-Ford algorithm 
          
 \param[in] Starting_Vertex             single source
 
 \param[in] rounding_error              rounding error for checking 
                                        negative cycle
                                        
 \param[out] boolean flag               indicate no negative cycles

 \param[out] shortest_path              shortest path array
 
 \param[out] predecessor                predecessor array
 
\ingroup graph.lua 

*/
]]
  BellmanFordShortestPath = function(Starting_Vertex, rounding_error)
  
    local -- shortest path array from Starting_Vertex
          shortest_path,
          vertexU, adjVertexOfU, weight, 
          -- predecessors vertex array
          predecessors,
          -- reachable vertex set of Starting_Vertex
          connectedVertexSet
    
    --initialization
    shortest_path = {}
    predecessors = {}
    
    -- initialize with starting vertex
    shortest_path[Starting_Vertex] = 0
    -- get connected vertex set of Starting_Vertex
    connectedVertexSet = getConnectedVertexSet(Starting_Vertex)
    
    for connectedVertex in connectedVertexSet.allElements() do
      
      -- relax edge weight
      for vertexU, adjVertexOfU, weight in allEdges() do
      
        if shortest_path[vertexU] ~= nil then
          
          if shortest_path[adjVertexOfU] == nil then
          
            shortest_path[adjVertexOfU] = shortest_path[vertexU] + weight
            
            predecessors[adjVertexOfU] = vertexU
          
          else
          
            if shortest_path[adjVertexOfU] > shortest_path[vertexU] + weight then
              
              shortest_path[adjVertexOfU] = shortest_path[vertexU] + weight
            
              predecessors[adjVertexOfU] = vertexU
            
            end
          
          end -- end of else if shortest_path[adjVertexOfU] == nil then
          
        end -- end of if shortest_path[vertexU] ~= nil then
      
      end -- end of for vertexU, adjVertexOfU, weight in allEdges() do
      
    end -- end of for connectedVertex in connectedVertexSet.allElements do
    
    
    -- check if there is a negative cycle
    for vertexU, adjVertexOfU, weight in allEdges() do
    
      if shortest_path[vertexU] ~= nil and shortest_path[adjVertexOfU] ~= nil then
        
        if shortest_path[vertexU] + weight < shortest_path[adjVertexOfU] then
          
          if rounding_error == nil then
            --a negative cycle is found!          
            return false, shortest_path, predecessors, adjVertexOfU
          
          else
          
            if math.abs(shortest_path[vertexU] + weight - shortest_path[adjVertexOfU]) > rounding_error then
              --a negative cycle is found!          
              return false, shortest_path, predecessors, adjVertexOfU
            
            end
            
          end -- end of if rounding_error == nil then
          
        end
      
      end -- end of if shortest_path[vertexU] ~= nil and shortest_path[adjVertexOfU] ~= nil then
    
    end -- end of for vertexU, adjVertexOfU, weight in allEdges() do
    
    return true, shortest_path, predecessors
    
  end

--[[
/*!
\function BreadthFirstSearch

\brief    Call pass in functors when iterate graph by breadth first
          search method.
          
 \param[in] Starting_Vertex             single source
 
 \param[out] connected_vertex_set       Connected vertex set from Starting_vertex
 
 \param[out] predecessors               1D table stores BFS path. 
                                        If vertex A ==> vertex B, then 
                                        predecessors["B"] = "A"
 
\ingroup graph.lua 

*/
]]
  BreadthFirstSearch = function(Starting_Vertex, flag, visit_functor, functor_state)
  
    flag = flag or false
  
    local predecessors = {}
    
    local connected_vertex_set = collection.NewSet()
    
    --initialize starting vertex
    connected_vertex_set.insert(Starting_Vertex, flag) 
   
  
    local vertexStack = collection.NewStack()
    vertexStack.push(Starting_Vertex)
    local vertex, adj_vertex
  
    while not vertexStack.isEmpty() do
  
      vertex = vertexStack.pop()
  
      if self.GraphMatrix[vertex] ~= nil then
  
        --iterate adjacent vertex
        for adj_vertex in allAdjacentVertexes(vertex) do
        
          if not connected_vertex_set.isContained(adj_vertex) then
          
            --BFS
            vertexStack.push(adj_vertex)
            
            -- add this adjacent vertex to connected vertex set
            connected_vertex_set.insert(adj_vertex, flag)
            
            -- update predecessors
            predecessors[adj_vertex] = vertex
            
            --call visit functors
            if visit_functor ~= nil then
            
              visit_functor(self.GraphMatrix, vertex, adj_vertex, functor_state)
              
            end-- end of if visit_functors ~= nil then
                        
          end--end of if not connected_vertex_set.isContained(adj_vertex) then
          
        end--end of for loop
  
      end --end if self.GraphMatrix[vertex] ~= nil then
  
    end--end of while not vertexStack.isEmpty() do
    
    --remove vertex itself
    connected_vertex_set.remove(Starting_Vertex)
  
    return connected_vertex_set, predecessors
    
  end-- end of BreadthFirstSearch = function(Starting_Vertex, visit_functor)

--[[
/*!
\function Extend_shortest_paths

\brief    relax path with one edge
          
 \param[in] L              source shortest graph
 
 \param[in] W              weight graph
 
 \param[out] M             improved shortest graph with one edge
 
\ingroup graph.lua         

*/
]]
  Extend_shortest_paths = function(L, W)
    
    local M = graph.NewGraph()
    
    local vertex_i, vertex_j, weight, vertex_k
    
    --loop through all edges where weight : vertex_i ==> vertex_j
    
    for vertex_i in L.allVertexes() do
      
      for vertex_j in L.allVertexes() do
        --initialize M
        weight = L.getWeight(vertex_i, vertex_j)
        
        if weight ~= nil then 
          M.setWeight(vertex_i, vertex_j, weight)
        end
        
        for vertex_k in L.allConnectedVertexes(vertex_i) do
                
          local M_weight_i_j = M.getWeight(vertex_i, vertex_j)
          
          local L_weight_i_k = L.getWeight(vertex_i, vertex_k)
          
          local W_weight_k_j = W.getWeight(vertex_k, vertex_j)
           
          if W_weight_k_j ~= nil and L_weight_i_k ~= nil then
          
            if M_weight_i_j == nil then
            
              M.setWeight(vertex_i, vertex_j, L_weight_i_k + W_weight_k_j)
              
            else
          
              -- relax weight between vertex i and j with new vertex k
              if  M_weight_i_j > L_weight_i_k + W_weight_k_j then
                
                M.setWeight(vertex_i, vertex_j, L_weight_i_k + W_weight_k_j)
                
              end -- end of if  M_weight_i_j > L_weight_i_k + W_weight_k_j then
              
            end--end of if W_weight_k_j ~= nil and L_weight_i_k ~= nil then
            
          end -- end of if W_weight_k_j ~= nil and L_weight_i_k ~= nil then
        
        end -- end of for vertex_k in L.allConnectedVertexes(vertex_i) do
      
      end -- end of for vertex_j in L.allVertexes() do
      
    end -- end of for for vertex_i in L.allVertexes() do
    
    return M
    
  end -- end of function 

--[[
/*!
\function checkAllPairsNegativeCycles

\brief    check if any negative cycles for all pairs shortest path algorithm
          
 \param[in] graph              input graph
 
 \param[in] rounding_error     rounding error
 
 \param[out] flag              boolean flag indicate if negative cycles not exists
 
\ingroup graph.lua

*/
]]
  checkAllPairsNegativeCycles = function(graph, rounding_error)
  
    local flag = true 
    
    local vertex      
    
    for vertex in graph.allVertexes() do
      
      local weight = graph.getWeight(vertex, vertex)
      
      if weight < 0 then
      
        if rounding_error == nil then
        
          flag = false
          
          break
          
        else
        
          if math.abs(weight) > rounding_error then
          
            flag = false
            
            break
            
          end
        
        end
      
      end
    
    end
    
    return flag
    
  end

--[[
/*!
\function AllPairsShortestPath

\brief    use matrix multiplication methodology to relax shortest path
          
 \param[in] rounding_error              rounding error for negative cycles detection
 
 \param[out] flag                       boolean flag indicate if negative cycles not exists
 
 \param[out] M                          shortest path of all pairs in the form of graph
 
\ingroup graph.lua 

*/
]]
  AllPairsShortestPath = function(rounding_error)
  
    -- initialize graph L with W
    local L = graph.NewGraph()
    
    local graphMatrixOfL = util.deepCopy(self.GraphMatrix)
    
    L.setGraphMatrix(graphMatrixOfL)
  
    local numVertex = getVertexSet().getNumElements()
    
    local vertex
    
    for vertex in L.allVertexes() do
      
      L.setWeight(vertex, vertex, 0)
      
    end
    
    local m = 1
    
    while m < numVertex - 1 do
    
      L = Extend_shortest_paths(L, L)
      
      m = 2 * m
      
    end
    
    -- check if negative cycles not exists
    
    local flag = checkAllPairsNegativeCycles(L, rounding_error)
    
    return flag, L
    
  end

--[[
/*!
\function FloydWarshallShortestPath

\brief    Floyd-Warshall algorithm find all pairs shortest paths
          
 \param[in] rounding_error             rounding error for negative cycles detection
 
 \param[out] flag                      boolean flag indicate if negative cycles not sexists
 
 \param[out] N                         shortest path of all pairs in the form of graph
 
\ingroup graph.lua 

*/
]]
  FloydWarshallShortestPath = function(rounding_error)
  
    -- initialize M with weight of input graph
    local N = graph.NewGraph() 
    
    N.setGraphMatrix(util.deepCopy(getGraphMatrix()))
    
    local vertex
    
    for vertex in N.allVertexes() do
    
      N.setWeight(vertex, vertex, 0)
    
    end
    
    local M = graph.NewGraph()

    local vertex_i, vertex_j, vertex_k
    
    for vertex_k in allVertexes() do
    
      for vertex_i in allVertexes() do
      
        for vertex_j in allVertexes() do
      
          local weight_i_j = N.getWeight(vertex_i, vertex_j)
          
          local weight_i_k = N.getWeight(vertex_i, vertex_k)      
          
          local weight_k_j = N.getWeight(vertex_k, vertex_j)   
          
          local new_weight   
          
          if weight_i_j == nil then
          
            if weight_i_k == nil or weight_k_j == nil then
      
              new_weight = nil
              
            else
              
              new_weight = weight_i_k + weight_k_j
                                        
            end -- end of else if weight_i_k == nil or weight_k_j == nil then
            
          else
          
            if weight_i_k == nil or weight_k_j == nil then
      
              new_weight = weight_i_j
              
            else
              
              new_weight = math.min(weight_i_k + weight_k_j, weight_i_j)
                                        
            end -- end of else if weight_i_k == nil or weight_k_j == nil then            
          
          end -- end of else if weight_i_j == nil then
          
          if new_weight ~= nil then
          
            M.setWeight(vertex_i, vertex_j, new_weight)
            
          end
          
        end -- end of for vertex_j in allVertexes() do
      
      end -- end of for vertex_i in allVertexes() do
      
      N = M
      
      M = graph.NewGraph()
      
    end -- end of for vertex_k in allVertexes() do
    
    -- check if negative cycles not exists
    
    local flag = checkAllPairsNegativeCycles(N, rounding_error)
    
    return flag, N
  
  end  
  
  -- publish public functions
  return {
          DijkstraShortestPath = DijkstraShortestPath,
          BellmanFordShortestPath = BellmanFordShortestPath,
          allAdjacentVertexes = allAdjacentVertexes,
          allConnectedVertexes = allConnectedVertexes,
          allVertexes = allVertexes,
          getVertexSet = getVertexSet,
          getConnectedVertexSet = getConnectedVertexSet,
          setGraphMatrix = setGraphMatrix,
          getGraphMatrix = getGraphMatrix,
          allEdges = allEdges,
          getWeight = getWeight,
          setWeight = setWeight,
          BreadthFirstSearch = BreadthFirstSearch,
          AllPairsShortestPath = AllPairsShortestPath,
          FloydWarshallShortestPath = FloydWarshallShortestPath
          }
          
end -- end of function graph.NewGraph()

return graph
