local graph = require "luastl.graph"

--
local sampleGraphMatrix = {
              ["A"] = {
                      ["B"] = 1,
                      ["C"] = 2,
                      ["D"] = 3,
                      ["E"] = 4
                      }
                      ,
              ["B"] = {
                      ["A"] = 3,
                      ["E"] = 1
                      }
                      ,
              ["F"] = {
                      ["G"] = 4,
                      ["H"] = 2
                      }
                      ,
              ["G"] = {
                      ["I"] = 3,
                      ["H"] = 5
                      }
                      ,
              ["H"] = {
                      ["J"] = 2
                      } 
              }
              
local connected_vertex_set
local vertex, starting_vertex, starting_vertex_set

local sGraph = graph.NewGraph()

sGraph.setGraphMatrix(sampleGraphMatrix)

-----------------------------------------------------------------------------
--
--  Unit test on connected_vertex_set, 
-----------------------------------------------------------------------------

-- Check connected vertex set of vertex A
local connected_vertex_set= sGraph.getConnectedVertexSet("A")
assert(connected_vertex_set.isContained("B") == true)
connected_vertex_set.remove("B")
assert(connected_vertex_set.isContained("C") == true)
connected_vertex_set.remove("C")
assert(connected_vertex_set.isContained("D") == true)
connected_vertex_set.remove("D")
assert(connected_vertex_set.isContained("E") == true)
connected_vertex_set.remove("E")
assert(connected_vertex_set.isEmpty() == true)

-- Check connected vertex set of vertex B
connected_vertex_set= sGraph.getConnectedVertexSet("B")
assert(connected_vertex_set.isContained("A") == true)
connected_vertex_set.remove("A")
assert(connected_vertex_set.isContained("C") == true)
connected_vertex_set.remove("C")
assert(connected_vertex_set.isContained("D") == true)
connected_vertex_set.remove("D")
assert(connected_vertex_set.isContained("E") == true)
connected_vertex_set.remove("E")
assert(connected_vertex_set.isEmpty() == true)

-- Check connected vertex set of vertex C
connected_vertex_set= sGraph.getConnectedVertexSet("C")
assert(connected_vertex_set.isEmpty() == true)

-- Check connected vertex set of vertex G
connected_vertex_set= sGraph.getConnectedVertexSet("G")
assert(connected_vertex_set.isContained("H") == true)
connected_vertex_set.remove("H")
assert(connected_vertex_set.isContained("I") == true)
connected_vertex_set.remove("I")
assert(connected_vertex_set.isContained("J") == true)
connected_vertex_set.remove("J")
assert(connected_vertex_set.isEmpty() == true)

-----------------------------------------------------------------------------
--
--  Unit test on allEdges iterator 
-----------------------------------------------------------------------------
local vertex, adjVertex, weight
local count =0
for vertex, adjVertex, weight in sGraph.allEdges() do
  assert(sampleGraphMatrix[vertex][adjVertex] == weight)
  count = count + 1
end
--should have 11 edges
assert(count == 11)
-----------------------------------------------------------------------------
--
--  Unit test on DijkstraShortestPath 
--  
-----------------------------------------------------------------------------
sGraph = nil

sampleGraphMatrix = nil

sGraph = graph.NewGraph()

sampleGraphMatrix = {
              ["s"] = {
                      ["t"] = 10,
                      ["y"] = 5
                      }
                      ,
              ["t"] = {
                      ["x"] = 1,
                      ["y"] = 2
                      }
                      ,
              ["y"] = {
                      ["t"] = 3,
                      ["x"] = 9,
                      ["z"] = 2
                      }
                      ,
              ["x"] = {
                      ["z"] = 4
                      }
                      ,
              ["z"] = {
                      ["s"] = 7,
                      ["x"] = 6
                      } 
              }
              
sGraph.setGraphMatrix(sampleGraphMatrix)

local shortest_path = sGraph.DijkstraShortestPath("s")

assert(shortest_path["s"] == 0)

assert(shortest_path["t"] == 8)

assert(shortest_path["y"] == 5)

assert(shortest_path["z"] == 7)

assert(shortest_path["x"] == 9)


local flag, shortest_path,_ = sGraph.BellmanFordShortestPath("s")
--should not have negative cycle
assert(flag == true)
assert(shortest_path["s"] == 0)

assert(shortest_path["t"] == 8)

assert(shortest_path["y"] == 5)

assert(shortest_path["z"] == 7)

assert(shortest_path["x"] == 9)
-----------------------------------------------------------------------------
--
--  Unit test on BellmanFordShortestPath 
--  
-----------------------------------------------------------------------------

-----------------------------------------------------------------------------
--
--  case 1 without negative cycle
-----------------------------------------------------------------------------
sGraph = nil

sampleGraphMatrix = nil

sGraph = graph.NewGraph()

sampleGraphMatrix = {
              ["s"] = {
                      ["t"] = 6,
                      ["y"] = 7
                      }
                      ,
              ["t"] = {
                      ["x"] = 5,
                      ["y"] = 8,
                      ["z"] = -4
                      }
                      ,
              ["y"] = {
                      ["x"] = -3,
                      ["z"] = 9
                      }
                      ,
              ["x"] = {
                      ["t"] = -2
                      }
                      ,
              ["z"] = {
                      ["s"] = 2,
                      ["x"] = 7
                      } 
              }
              
sGraph.setGraphMatrix(sampleGraphMatrix)

local flag, shortest_path, predecessors

flag, shortest_path, predecessors = sGraph.BellmanFordShortestPath("s")

--no negative cycle
assert(flag == true)

assert(shortest_path["s"] == 0)

assert(shortest_path["t"] == 2)
assert(predecessors["t"] == "x")

assert(shortest_path["y"] == 7)
assert(predecessors["y"] == "s")

assert(shortest_path["z"] == -2)
assert(predecessors["z"] == "t")

assert(shortest_path["x"] == 4)
assert(predecessors["x"] == "y")

-----------------------------------------------------------------------------
--
--  case 2 with negative cycle
--  
-----------------------------------------------------------------------------
sGraph = nil

sampleGraphMatrix = nil

sGraph = graph.NewGraph()

sampleGraphMatrix = {
              ["s"] = {
                      ["t"] = 6,
                      ["y"] = 7
                      }
                      ,
              ["t"] = {
                      ["x"] = 5,
                      ["y"] = 8,
                      ["z"] = -4
                      }
                      ,
              ["y"] = {
                      ["x"] = -3,
                      ["z"] = 9
                      }
                      ,
              ["x"] = {
                      ["t"] = -4
                      }
                      ,
              ["z"] = {
                      ["s"] = 2,
                      ["x"] = 7
                      } 
              }
              
sGraph.setGraphMatrix(sampleGraphMatrix)

local flag, shortest_path, predecessors

flag, shortest_path, predecessors, lastVertex = sGraph.BellmanFordShortestPath("s")

--should have negative cycle
assert(flag == false)


-----------------------------------------------------------------------------
--
--  Unit test on AllPairsShortestPath and FloydWarshallShortestPath
--  
-----------------------------------------------------------------------------

-----------------------------------------------------------------------------
--  all pairs shortest path
--  case 1 without negative cycles
-----------------------------------------------------------------------------
sGraph = nil

sampleGraphMatrix = nil

sGraph = graph.NewGraph()

sampleGraphMatrix = {
              ["1"] = {
                      ["2"] = 3,
                      ["3"] = 8,
                      ["5"] = -4
                      }
                      ,
              ["2"] = {
                      ["4"] = 1,
                      ["5"] = 7
                      }
                      ,
              ["3"] = {
                      ["2"] = 4
                      }
                      ,
              ["4"] = {
                      ["1"] = 2,
                      ["3"] = -5
                      }
                      ,
              ["5"] = {
                      ["4"] = 6
                      } 
              }
              
sGraph.setGraphMatrix(sampleGraphMatrix)

-- result benchmark matrix
local resultGraphMatrix ={
                  ["1"] ={
                          ["1"] = 0,
                          ["2"] = 1,
                          ["3"] = -3,
                          ["4"] = 2,
                          ["5"] = -4
                          }
                          ,
                   ["2"] ={
                          ["1"] = 3,
                          ["2"] = 0,
                          ["3"] = -4,
                          ["4"] = 1,
                          ["5"] = -1
                          }
                          ,
                   ["3"] ={
                          ["1"] = 7,
                          ["2"] = 4,
                          ["3"] = 0,
                          ["4"] = 5,
                          ["5"] = 3
                          }
                          ,
                   ["4"] ={
                          ["1"] = 2,
                          ["2"] = -1,
                          ["3"] = -5,
                          ["4"] = 0,
                          ["5"] = -2
                          }
                          ,
                   ["5"] ={
                          ["1"] = 8,
                          ["2"] = 5,
                          ["3"] = 1,
                          ["4"] = 6,
                          ["5"] = 0
                          }
                      }

-----------------------------------------------------------------------------
--  AllPairsShortestPath 
-----------------------------------------------------------------------------
local flag, allPairsShortestGraph = sGraph.AllPairsShortestPath()
-- no negative cycles
assert(flag == true)

local vertex_i, vertex_j, result
-- check all pairs shortest path
for vertex_i, vertex_j, result in allPairsShortestGraph.allEdges() do

  assert (result == resultGraphMatrix[vertex_i][vertex_j])

end

-----------------------------------------------------------------------------
--  FloydWarshallShortestPath 
-----------------------------------------------------------------------------
flag, allPairsShortestGraph = sGraph.FloydWarshallShortestPath()
-- negative cycle doesn't exist
assert(flag == true)

local vertex_i, vertex_j, result
-- check all pairs shortest path
for vertex_i, vertex_j, result in allPairsShortestGraph.allEdges() do

  assert (result == resultGraphMatrix[vertex_i][vertex_j])

end

-----------------------------------------------------------------------------
--  all pairs shortest paths
--  case 2 with negative cycle
-----------------------------------------------------------------------------
sGraph = nil

sampleGraphMatrix = nil

sGraph = graph.NewGraph()

sampleGraphMatrix = {
              ["s"] = {
                      ["t"] = 6,
                      ["y"] = 7
                      }
                      ,
              ["t"] = {
                      ["x"] = 5,
                      ["y"] = 8,
                      ["z"] = -4
                      }
                      ,
              ["y"] = {
                      ["x"] = -3,
                      ["z"] = 9
                      }
                      ,
              ["x"] = {
                      ["t"] = -4
                      }
                      ,
              ["z"] = {
                      ["s"] = 2,
                      ["x"] = 7
                      } 
              }

sGraph.setGraphMatrix(sampleGraphMatrix)

flag, allPairsShortestGraph = sGraph.AllPairsShortestPath()

-- negative cycles exist
assert(flag == false)

flag, allPairsShortestGraph = sGraph.FloydWarshallShortestPath()
-- negative cycles exist
assert(flag == false)
             
print("Passed unit test for Graph library!")
  
