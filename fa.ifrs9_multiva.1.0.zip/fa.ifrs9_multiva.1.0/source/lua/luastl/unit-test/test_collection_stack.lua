local collection = require "luastl.collection"

local dfs = collection.NewStack()

assert(dfs.isEmpty() == true)

local strHello = "hello"
dfs.push(strHello)

assert (dfs.pop() == "hello")

assert(dfs.isEmpty() == true )

dfs.push(1)

dfs.push(2)

assert(dfs.isEmpty() == false )

assert(dfs.pop() == 2)

assert(dfs.pop() == 1)

print("Passed unit test for collection.NewStack!")