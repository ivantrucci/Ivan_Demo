local collection = require "luastl.collection"

local mySet = collection.NewSet()

assert(mySet.isEmpty() == true)

mySet.insert(1)
mySet.insert(2)
mySet.remove(2)
mySet.remove(4)

assert(mySet.isEmpty() == false)

assert(mySet.isContained(2) == false)

assert(mySet.isContained(4) == false)

assert(mySet.isContained(1) == true)

mySet = nil

-- test allElements iterators
local testSet = collection.NewSet()
local testElement = {2, 3, 5, 7, 11}
local i
local total = 0

for _, i in ipairs(testElement) do
  
  testSet.insert(i)

end

for i in testSet.allElements() do

  total = total + i
  
end

assert (total == 28)

print("Passed unit test for collection.NewSet!")