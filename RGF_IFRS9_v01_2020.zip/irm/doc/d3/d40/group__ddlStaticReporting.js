var group__ddlStaticReporting =
[
    [ "data_extraction_config.sas", "db/d28/data__extraction__config_8sas.html", null ],
    [ "report_config.sas", "da/d8a/report__config_8sas.html", null ],
    [ "report_option.sas", "d7/d94/report__option_8sas.html", null ],
    [ "report_parameters.sas", "d9/d8d/report__parameters_8sas.html", null ],
    [ "va_report_config.sas", "d1/dca/va__report__config_8sas.html", null ]
];