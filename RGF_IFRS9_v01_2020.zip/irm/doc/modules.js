var modules =
[
    [ "Analytics", "d3/d4d/group__analytics.html", "d3/d4d/group__analytics" ],
    [ "IFRS9 Nodes", "dd/d58/group__nodes.html", "dd/d58/group__nodes" ],
    [ "Input Data Model", "d5/df2/group__datamodel.html", "d5/df2/group__datamodel" ]
];