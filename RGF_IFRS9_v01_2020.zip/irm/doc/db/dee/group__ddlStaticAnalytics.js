var group__ddlStaticAnalytics =
[
    [ "aggregation_config.sas", "df/d01/aggregation__config_8sas.html", null ],
    [ "calculation_config.sas", "db/d3f/calculation__config_8sas.html", null ],
    [ "data_map_config.sas", "d6/de6/data__map__config_8sas.html", null ],
    [ "enrichment_config.sas", "df/d20/enrichment__config_8sas.html", null ],
    [ "execution_config.sas", "d8/df9/execution__config_8sas.html", null ],
    [ "reportmart_config.sas", "d1/d0a/reportmart__config_8sas.html", null ],
    [ "var_dependency_config.sas", "d5/ddf/var__dependency__config_8sas.html", null ]
];