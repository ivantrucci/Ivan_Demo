var group__ddlStaticDQ =
[
    [ "dq_config.sas", "d5/d7e/dq__config_8sas.html", null ],
    [ "rule_set_config.sas", "d3/d85/rule__set__config_8sas.html", null ]
];