var group__ddlFactRiskFactors =
[
    [ "rf_curve.sas", "d3/da0/rf__curve_8sas.html", null ]
];