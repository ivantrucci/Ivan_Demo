var group__ddlStatic =
[
    [ "Analysis Configuration", "db/dee/group__ddlStaticAnalytics.html", "db/dee/group__ddlStaticAnalytics" ],
    [ "Data Quality and Rule Sets", "d1/d6d/group__ddlStaticDQ.html", "d1/d6d/group__ddlStaticDQ" ],
    [ "Jobflow Parameters", "da/dde/group__ddlStaticFlow.html", "da/dde/group__ddlStaticFlow" ],
    [ "Reporting Configuration", "d3/d40/group__ddlStaticReporting.html", "d3/d40/group__ddlStaticReporting" ]
];