var searchData=
[
  ['organizational_20setup',['Organizational setup',['../d7/d02/group__ddlFactEntity.html',1,'']]]
];
