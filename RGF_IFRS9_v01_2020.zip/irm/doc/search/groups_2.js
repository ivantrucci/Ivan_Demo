var searchData=
[
  ['data_20quality_20and_20rule_20sets',['Data Quality and Rule Sets',['../d1/d6d/group__ddlStaticDQ.html',1,'']]],
  ['dynamic_20portfolio_20analytics',['Dynamic Portfolio Analytics',['../df/d31/group__DynamicPortfolio.html',1,'']]]
];
