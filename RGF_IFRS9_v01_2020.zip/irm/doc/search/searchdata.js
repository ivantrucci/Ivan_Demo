var indexSectionsWithContent =
{
  0: "abcdefijmoprsv",
  1: "acdeimprv",
  2: "acdijmoprs",
  3: "abcdfiprs"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "groups",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Modules",
  3: "Pages"
};

