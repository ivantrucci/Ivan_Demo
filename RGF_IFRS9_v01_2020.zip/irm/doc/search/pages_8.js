var searchData=
[
  ['solution_20architecture',['Solution Architecture',['../dd/dcf/050solarchitecture.html',1,'']]]
];
