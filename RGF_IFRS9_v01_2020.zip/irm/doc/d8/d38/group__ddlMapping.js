var group__ddlMapping =
[
    [ "map_dpd_type.sas", "db/dd1/map__dpd__type_8sas.html", null ],
    [ "map_geo_hierarchy.sas", "d7/d1b/map__geo__hierarchy_8sas.html", null ],
    [ "map_lob_hierarchy.sas", "d9/d1e/map__lob__hierarchy_8sas.html", null ],
    [ "map_ltv_type.sas", "da/dd8/map__ltv__type_8sas.html", null ],
    [ "map_product_hierarchy.sas", "d5/d99/map__product__hierarchy_8sas.html", null ]
];