var group__datamodel =
[
    [ "Configuration tables", "da/de4/group__ddlStatic.html", "da/de4/group__ddlStatic" ],
    [ "Mapping tables", "d8/d38/group__ddlMapping.html", "d8/d38/group__ddlMapping" ],
    [ "Staging tables", "d6/d17/group__ddlFact.html", "d6/d17/group__ddlFact" ]
];