#!/bin/sh

POSITIONAL=()
while [[ $# -gt 0 ]]
do
key="$1"

case $key in
   -metaserver|--metaserver)
   export METADATAHOST="$2"
   shift # past argument
   shift # past value
   ;;
   -metaport|--metaport)
   export METAPORT="$2"
   shift # past argument
   shift # past value
   ;;
   -metarepository|--metarepository)
   export METAREPOS="$2"
   shift # past argument
   shift # past value
   ;;
   -metauser|--metauser)
   export SASADMUSER="$2"
   shift # past argument
   ;;
   -metapass|--metapass)
   export SASADMPASS="$2"
   shift # past argument
   ;;
   -user|--user)
   export SASUSER="$2"
   shift # past argument
   ;;
   -password|--password)
   export SASPASSWORD="$2"
   shift # past argument
   ;;
   -lev_path|--lev_path)
   export SASCONFLEV="$2"
   shift # past argument
   ;;
   -content_path|--content_path)
   export CONTENT_PATH="$2"
   shift # past argument
   ;;
   -actions_xlsx|--actions_xlsx)
   export ACTIONS_XLSX="$2"
   shift # past argument
   ;;
   -log_path|--log_path)
   export BASELOG_DIR_PATH="$2"
   shift # past argument
   ;;
   -load_sample|--load_sample)
   export LOAD_SAMPLE="$2" 
   shift # past argument
   ;;
   *)    # unknown option
   POSITIONAL+=("$1") # save it in an array for later
   shift # past argument
   ;;
esac
done
set -- "${POSITIONAL[@]}" # restore positional parameters

# Usage instructions
USAGE="Usage: \n   cdt_unix.sh"
USAGE="$USAGE \n      -metaserver <host>"
USAGE="$USAGE \n      -metarepository <Metadata Repository>"
USAGE="$USAGE \n      -metaport <Metadata Server Port>"
USAGE="$USAGE \n      -metauser <Metadata Administrator userid>"
USAGE="$USAGE \n      -metapass <Metadata Administrator password>"
USAGE="$USAGE \n      -user <userid>"
USAGE="$USAGE \n      -password <password>"
USAGE="$USAGE \n      -lev_path <SAS Lev# directory path>"
USAGE="$USAGE \n      -content_path <content path>"
USAGE="$USAGE \n      -actions_xlsx <filename.xlsx>"
USAGE="$USAGE \n      -log_path <Log directory path>"
USAGE="$USAGE \n      -load_sample <YES|NO>\n"

echo "-----------------------------------------------"
echo "         Content Deployment Tool"
echo "-----------------------------------------------"
echo
echo "Checking input parameters.."

# Set Default Parameters if empty


if [ -z "$METADATAHOST" ]; then
   echo "-> Using default option: -metaserver localhost"
   export METADATAHOST=localhost
fi
if [ -z "$METAPORT" ]; then
   echo "-> Using default option: -metaport 8561"
   export METAPORT=8561
fi
if [ -z "$METAREPOS" ]; then
   echo "-> Using default option: -metarepository Foundation"
   export METAREPOS=Foundation
fi
if [ -z "$ACTIONS_XLSX" ]; then
   echo "-> Using default option: -actions_xlsx actions.xlsx"
   export ACTIONS_XLSX=actions.xlsx
fi

if [ -z "$LOAD_SAMPLE" ]; then
   export LOAD_SAMPLE=YES
   echo "-> Using default option: -load_sample $LOAD_SAMPLE"
   
fi

## Check for required parameters
if [ -z "$SASADMUSER" ]; then
   echo "ERROR: required option -metauser has not been specified"
   printf "$USAGE"
   exit 1
fi
if [ -z "$SASADMPASS" ]; then
   echo "ERROR: required option -metapass has not been specified"
   printf "$USAGE"
   exit 1
fi
if [ -z "$SASCONFLEV" ]; then
   echo "ERROR: required option -lev_path has not been specified"
   printf "$USAGE"
   exit 1
fi
if [ -z "$CONTENT_PATH" ]; then
   echo "ERROR: required option -content_path has not been specified"
   printf "$USAGE"
   exit 1
fi

## Check for User/Password parameters
if [ -z "$SASUSER" ]; then
   echo "-> Option -user has not been specified. Using the provided -metauser value"
   export SASUSER=$SASADMUSER
fi
if [ -z "$SASPASSWORD" ]; then
   echo "-> Option -password has not been specified. Using the provided -metapass value"
   export SASPASSWORD=$SASADMPASS
fi



## Set the tool directory
export CR_TOOLPATH=$(dirname $(readlink -f $0))

if [ -z "$BASELOG_DIR_PATH" ]; then
   echo "-> Using default option: -log_path $CR_TOOLPATH/log/"
   export BASELOG_DIR_PATH=$CR_TOOLPATH/log/
fi

#export LOGIN_WKSHEET=login
export CURRENT_PATH=`pwd`

mkdir -p $BASELOG_DIR_PATH

. $SASCONFLEV/level_env.sh

#
#File env.properties file can be sourced for token substitution in .sas files. This will allow content to decide any tokens for replacement. 
#
env > $BASELOG_DIR_PATH/env.properties

export JOBFILE=$CR_TOOLPATH/main.sas
export LOGFILE=$BASELOG_DIR_PATH/cr_tool.log

export ERROR_JOBFILE=$CR_TOOLPATH/scan_log_groovy.sas
export ERROR_LOGFILE=$BASELOG_DIR_PATH/cr_tool_error.log


echo "START TIME  ::" `date`
startdate=`date`
$SAS_COMMAND -sysin $JOBFILE  -batch -log $LOGFILE  -noterminal 
rc=$?

echo "SAS exited with : $rc. Log file: $LOGFILE. "
enddate=`date`
echo "END TIME  ::" `date`

echo "Checking errors..."
$SAS_COMMAND -sysin $ERROR_JOBFILE  -batch -log $ERROR_LOGFILE  -noterminal -nonotes -nosource -nonews
cat $ERROR_LOGFILE


