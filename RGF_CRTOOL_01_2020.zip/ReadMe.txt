SAS and all other SAS Institute product or service names are 
registered trademarks or trademarks of SAS Institute Inc. in the USA 
and other countries. Other brand and product names are registered 
trademarks or trademarks of their respective companies. ® indicates 
USA registration. Copyright (c) 2019 SAS Institute Inc., Cary, NC, 
USA. All rights reserved. 

Pre-Requisite :
1. This tool should be executed on SAS Compute Tier where we have SAS Foundation available.



2. For RGF (Risk Governance Framework) Only:  On the SAS Compute tier : Ensure Risk Governance Framework Administrative Tool is installed and configured.
Administrative Tool must have password set for : 
<SASConfig/Lev1>/Applications/SASRiskGovernanceFrameworkAdministrativeTools/properties/db.AdminTools.properties
monitor.db.connection.password=
wip.db.connection.password=


3. If you are running tool on windows make sure your command line runs as administrator. You can do this by right clicking on cmd.exe and select 'Run as administrator'.

Steps :
1> Verify  Admintools (RGF Only) : 
cd to <SASConfig/Lev1>/Applications/SASRiskGovernanceFrameworkAdministrativeTools/dbscripts
Run command: sh verifyEnvironment.sh(for UNIX) or verifyEnvironment.cmd (for windows).
It should run without any prompts and show you success message. 

2> Tool and Content zip should be unzipped at some location on SAS Compute tier. 
**Login to SAS compute tier as SAS install user.
For tool : 
Create dir /tmp/cdt/tool for UNIX
C:\temp\cdt\tool for Windows.   
Copy tool zip to above dir and unzip it.
For Content : 
Create dir  :/tmp/cdt/content for UNIX
            C:\temp\cdt\content for Windows.
Copy content zip to above dir and unzip it

3> Only for LINUX : Set DISPLAY env variable : example : export DISPLAY=<machineName>:0.0.  The machineName here is the hostname of X Server.
   For checking DISPLAY : Run command xhost and check for success.

4> Go to tool dir:
You will have cdt_unix.sh or cdt_wx6.cmd. In this step we will update required variables. 
For UNIX provide executable permissions to cdt_unix.sh 
Command : chmod +x cdt_unix.sh 
cdt_unix.sh -metaserver <host>  -metarepository <Metadata Repository> -metaport <Metadata Server Port>  -metauser <userid> -metapass <password> -lev_path <SAS Lev# directory path> -content_path <content path> -actions_xlsx <filename.xlsx> -log_path <Log directory path>

For cdt_wx6.cmd : Change following variables based on your env: 
cdt_wx6.cmd /metaserver:<host>  /metarepository:<Metadata Repository> /metaport:<Metadata Server Port>  /metauser:<userid> /metapass:<password> /lev_path:<SAS Lev# directory path> /content_path:<content path> /actions_xlsx:<filename.xlsx> /log_path:<Log directory path>

**Details of variables: 
=>METADATAHOST : Metadata host fully qualified name. 
=>METAPORT : Metadata port : Default 8561
=>METAREPOS : Metadata repository  : Default is Foundation 
=>SASADMUSER : This can be sasadm@saspw or id the content need access to file system (MRM for e.g) for e.g import of SAS stored process spk then it should be physical user with Role : SAS Administration and Metadata Unrestricted

=>SASADMPASS : sasadm@saspw (SAS Administrator) password or similar user password. You can set SASADMPASS as encrypted. 
  Run following statement in your SAS editor. Console will show password. Copy it and use its value in SASADMPASS.  
  SAS Statement : proc pwencode in='<yourpass>'; run;
  
=>SASCONFLEV : SAS Config path including Lev directory.
=>CR_TOOLPATH : Absolute path to tool where you found this ReadMe.txt. 
=>CONTENT_PATH : Absolute path where content is unzipped. The directory provided must contain xlsx : actions.xlsx.
=>ACTION_XLSX : Defaults to actions.xlsx but you can provide any xlsx name that you want to use. File with this name must present in CONTENT_PATH.

5> Set current directory to tool path (CR_TOOLPATH) where we have this ReadMe.txt
   Command : cd <CR_TOOLPATH>

6> Run updated cdt_unix.sh or cdt_wx6.cmd.
   Command for UNIX : sh cdt_unix.sh 
   
7> Sometimes it may take while for content to load.  All logs are found in 'log' or log_path args directory from where you ran sh or cmd file.

8> Once execution completes console would show SAS exit code and scan errors.

9> Optional : You might need to restart appropriate SASServer_X based on content documentation.


