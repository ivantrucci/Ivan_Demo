
import org.apache.tools.ant.Project
import com.sas.metadata.remote.*
//import com.sas.meta.SASOMI.ISecurity_1_1;
import com.sas.meta.SASOMI.*
		
/* import com.sas.batch.localsvc.ScriptingLocalServicesContext;
import com.sas.services.user.UserContextInterface;
import com.sas.services.information.metadata.servers.LASRServerUtil;*/


class MetadataUtilityClassInternal {

     def MdFactoryImpl factory
     def MdOMRConnection omrConnection
     def MdObjectStore mdObjectStore
     def project
     def fqId
     def reposId

     def debug = false

     /**
      * Constructor
      */
/**
 * Returns MdOMRConnection object that can then be used to query or update metadata. 
 * It sets class public variable omrConnection.
 *
 * @param  host  Metadata
 * @param  port  Metadata port
 * @param  user  Metadata user
 * @param  password  Metadata port
 * @param  repositoryName  Metadata repository name
 * @return      MdOMRConnection omrConnection
 */
     MdOMRConnection makeConnection(host, port, user, password, reposName) {
          factory = new MdFactoryImpl(false)
          factory.setDebug(true)

          if (debug) {
               // Enable logging
               factory.setLoggingEnabled(true)
               // Set the output streams for logging.  The logging output can be
               // directed to any OutputStream, including a file.
               factory.getUtil().setOutputStream(System.out)
               factory.getUtil().setLogStream(System.out)
          }

          factory.makeOMRConnection(host, port, user, password);
          omrConnection = factory.getConnection();
          if (omrConnection == null) {
               e1 = new MdException("Error connecting to metadata server.")
               throw e1
          } else {

               println("Connected to metadata server. ::Debug=="+ debug)
          }
          mdObjectStore = factory.createObjectStore()
          extractRposFqid(reposName)
          return omrConnection
     }

     void extractRposFqid(reposName) {
          def MdRepositoryUtil repositories = factory.getRepositoryUtil()
          fqId = repositories.getRepositoryIDFromName(reposName)
          repositories.dispose()
          if (fqId == null) {
               e1 = new MdException("Error getting ID for repository, ${reposName}.")
               throw e1
          } else {
               reposId=fqId.substring(9)
          }
     }
	 

 
     void closeConnection() {
          if (mdObjectStore != null) {
               try {
                    mdObjectStore.dispose()
               }
               catch (Exception e99) {

                    println(project+ "closeConnection: " + e99.getMessage() + debug)
               }
          }
          if (omrConnection != null) {
               try {
                    omrConnection.closeOMRConnection()
               }
               catch (Exception e) {
                    println(project + "closeConnection: " + e.getMessage()+ debug)
               }
          }
     }


/**
 * Returns List of matching objects based on xmlSelect search & metadata Type
 *
 * @param  mdType  Metadata Type like TREE , TABLE etc. 
 * @param  xmlSelect  xmlSelect query
 * @return  List 
 */

     List findMetadataObjects(mdType, xmlSelect) {
          def MdOMIUtil util = factory.getOMIUtil()
          List objectList = util.getMetadataObjectsSubset(mdObjectStore, fqId, mdType,
                      util.OMI_XMLSELECT
                    | util.OMI_GET_METADATA
                    | util.OMI_ALL
                    | util.OMI_ALL_SIMPLE,
                    xmlSelect
                    )
          return objectList
     }

     List findMetadataRootObjects(xmlSelect) {
          def mdType = MetadataObjects.ROOT
          def MdOMIUtil util = factory.getOMIUtil()
          List objectList = util.getMetadataObjectsSubset(mdObjectStore, fqId, mdType,
                      util.OMI_XMLSELECT
                    | util.OMI_GET_METADATA
                    | util.OMI_ALL
                    | util.OMI_ALL_SIMPLE
                    | util.OMI_INCLUDE_SUBTYPES,
                    xmlSelect
                    )
          return objectList
     }

     void deleteObject(object) {
          factory.deleteMetadataObject(object)
     }

     Root findObject(fqid) {
          def xmlSelect= "<XMLSELECT Search=\"Root[@Id='${fqid}']\"/>"
          def mdObject
          def found = findMetadataRootObjects(xmlSelect);
          if (found != null && found.size() > 0) {
               mdObject = (Root)found.get(0)
          }
          return mdObject
     }
	 
	 
/**
 * Returns metadata library object
 *
 * @param  searchPath  Library Name
 * @return  SASLibrary 
 */


     SASLibrary findLibrary(searchPath) {
          def mdType = MetadataObjects.SASLIBRARY
          def xmlSelect= "<XMLSELECT Search=\"${mdType}${searchPath}\"/>"
          def mdObject
          def found = findMetadataObjects(mdType, xmlSelect);
          if (found != null && found.size() > 0) {
               mdObject = (SASLibrary)found.get(0)
          }
          return mdObject
     }

	 
     IdentityGroup getGroupByFqid(fqid) {
          def mdType = MetadataObjects.IDENTITYGROUP
          def xmlSelect= "<XMLSELECT Search=\"${mdType}[@Id='${fqid}']\"/>"
          def mdObject
          def found = findMetadataObjects(mdType, xmlSelect);
          if (found != null && found.size() > 0) {
               mdObject = (IdentityGroup)found.get(0)
          }
          return mdObject
     }

	/**
	* Returns metadata IdentityGroup object
	*
	* @param  name  Metadata Group Name
	* @return  IdentityGroup 
	*/

     IdentityGroup getGroupByName(name) {
          def mdType = MetadataObjects.IDENTITYGROUP
          def xmlSelect= "<XMLSELECT Search=\"${mdType}[@Name='${name}']\"/>"
          def mdObject
          def found = findMetadataObjects(mdType, xmlSelect);
          if (found != null && found.size() > 0) {
               mdObject = (IdentityGroup)found.get(0)
          }
          return mdObject
     }

     Machine getMachine(name) {
          String mdType = MetadataObjects.MACHINE
          def xmlSelect = "<XMLSELECT Search=\"@Name='${name}'\"/>"
          def mdObject
          List found = findMetadataObjects(mdType, xmlSelect);
          if (found != null && found.size() > 0) {
               mdObject = (Machine)found.get(0)
          }
          return mdObject
     }

     AuthenticationDomain getAuthDomain(name) {
          def mdType = MetadataObjects.AUTHENTICATIONDOMAIN
          def xmlSelect = "<XMLSELECT Search=\"@Name='${name}'\"/>"
          def mdObject
          List found = findMetadataObjects(mdType, xmlSelect)
          if (found != null && found.size() > 0) {
               mdObject = (AuthenticationDomain)found.get(0)
          }
          return mdObject
     }

     Login getLogin(userId) {
          def mdType = MetadataObjects.LOGIN
          def xmlSelect = "<XMLSELECT Search=\"@UserID='${userId}'\"/>"
          def mdObject
          List found = findMetadataObjects(mdType, xmlSelect)
          if (found != null && found.size() > 0) {
               mdObject = (Login)found.get(0)
          }
          return mdObject
     }

     Login getLoginWithDomain(userId, domain) {
          def mdType = MetadataObjects.LOGIN
          def xmlSelect = "<XMLSELECT Search=\"${mdType}[@UserID='${userId}'][Domain/*[@Name='${domain}']]\"/>"
          def mdObject
          List found = findMetadataObjects(mdType, xmlSelect)
          if (found != null && found.size() > 0) {
               mdObject = (Login)found.get(0)
          }
          return mdObject
     }

     SASClientConnection getSCConnection(name) {
          def mdType = MetadataObjects.SASCLIENTCONNECTION
          def xmlSelect = "<XMLSELECT Search=\"@Name='${name}'\"/>"
          def mdObject
          List found = findMetadataObjects(mdType, xmlSelect)
          if (found != null && found.size() > 0) {
               mdObject = (SASClientConnection)found.get(0)
          }
          return mdObject
     }

    SASClientConnection getConnectionToServer(name, serverName) {
        def mdType = MetadataObjects.SASCLIENTCONNECTION
        def xmlSelect = "<XMLSELECT Search=\"${mdType}[@Name='${name}'][Source/*[@Name='${serverName}']]\"/>"
        def mdObject
        List found = findMetadataObjects(mdType, xmlSelect)
        if (found != null && found.size() > 0) {
            mdObject = (SASClientConnection)found.get(0)
        }
        return mdObject
    }

     ServerContext getServerContext(name) {
          def mdType = MetadataObjects.SERVERCONTEXT
          def xmlSelect = "<XMLSELECT Search=\"@Name='${name}'\"/>"
          def mdObject
          List found = findMetadataObjects(mdType, xmlSelect)
          if (found != null && found.size() > 0) {
               mdObject = (ServerContext)found.get(0)
          }
          return mdObject
     }

     SASLibrary getSasLibrary(name) {
          def mdType = MetadataObjects.SASLIBRARY
          def xmlSelect = "<XMLSELECT Search=\"@Name='${name}'\"/>"
          def mdObject
          List found = findMetadataObjects(mdType, xmlSelect)
          if (found != null && found.size() > 0) {
               mdObject = (SASLibrary)found.get(0)
          }
          return mdObject
     }

     Tree getMetadataFolder(searchString) {
          def mdType = MetadataObjects.TREE
          def xmlSelect = "<XMLSELECT Search=\"${mdType}${searchString}\"/>"
          def mdObject
          List found = findMetadataObjects(mdType, xmlSelect)
          if (found != null && found.size() > 0) {
               mdObject = (Tree)found.get(0)
          }
          return mdObject
     }

     Property getProperty(name) {
          def mdType = MetadataObjects.PROPERTY
          def xmlSelect = "<XMLSELECT Search=\"@Name='${name}'\"/>"
          def mdObject
          List found = findMetadataObjects(mdType, xmlSelect)
          if (found != null && found.size() > 0) {
               mdObject = (Property)found.get(0)
          }
          return mdObject
     }

     PropertySet getPropertySet(name, libname) {
          def mdType = MetadataObjects.PROPERTYSET
          def xmlSelect = "<XMLSELECT Search=\"${mdType}[@Name='${name}'][OwningObject/*[@Name='${libname}']\"/>"
          def mdObject
          List found = findMetadataObjects(mdType, xmlSelect)
          if (found != null && found.size() > 0) {
               mdObject = (PropertySet)found.get(0)
          }
          return mdObject
     }

     ServerComponent getServerComponent(name){
          def mdType = MetadataObjects.SERVERCOMPONENT
          def xmlSelect = "<XMLSELECT Search=\"@Name='${name}'\"/>"
          def sComp
          List found = findMetadataObjects(mdType, xmlSelect)
          if (found != null && found.size() > 0) {
               sComp = (ServerComponent)found.get(0)
          }
          return sComp
     }

     Directory getDirectory(name){
          def mdType = MetadataObjects.DIRECTORY
          def xmlSelect = "<XMLSELECT Search=\"@Name='${name}'\"/>"
          def mdDir
          List found = findMetadataObjects(mdType, xmlSelect)
          if (found != null && found.size() > 0) {
               mdDir = (Directory)found.get(0)
          }
          return mdDir
     }

     ServerComponent makeServerComponent(name) {
          def type = MetadataObjects.SERVERCOMPONENT
          def newMdObject = (ServerComponent)factory.createComplexMetadataObject(mdObjectStore, null, name, type, reposId)
          return newMdObject
     }

     SASClientConnection makeSasClientConnection(name) {
          def type = MetadataObjects.SASCLIENTCONNECTION
          def newMdObject = (SASClientConnection)factory.createComplexMetadataObject(mdObjectStore, null, name, type, reposId)
          return newMdObject
     }

     TCPIPConnection makeTCPIPConnection(name) {
          def type = MetadataObjects.TCPIPCONNECTION
          def newMdObject = (TCPIPConnection)factory.createComplexMetadataObject(mdObjectStore, null, name, type, reposId)
          return newMdObject
     }

     AssociationList makeServiceType(name, association) {
          def type = MetadataObjects.SERVICETYPE
          def newMdObject = factory.createComplexMetadataObject(mdObjectStore, null, name, type, reposId)
          def aList = new AssociationList(association, 1)
          aList.add(newMdObject)
          return aList
     }

     SASLibrary makeSasLibrary(name) {
          def type = MetadataObjects.SASLIBRARY
          def newMdObject = (SASLibrary)factory.createComplexMetadataObject(mdObjectStore, null, name, type, reposId)
          return newMdObject
     }
	 
	 

     TextStore makeTextStore(name) {
          def type = MetadataObjects.TEXTSTORE
          def newMdObject = (TextStore)factory.createComplexMetadataObject(mdObjectStore, null, name, type, reposId)
          return newMdObject
     }

     DatabaseSchema makeDatabaseSchema(name) {
          def type = MetadataObjects.DATABASESCHEMA
          def newMdObject = (DatabaseSchema)factory.createComplexMetadataObject(mdObjectStore, null, name, type, reposId)
          return newMdObject
     }

     PropertySet makePropertySet(name) {
          def type = MetadataObjects.PROPERTYSET
          def newMdObject = (PropertySet)factory.createComplexMetadataObject(mdObjectStore, null, name, type, reposId)
          return newMdObject
     }

   Property makeNewSetProperty(t, name, defaultValue) {
      // Named arguments: propertyName:"Text"
      if (t.propertyName == null) { t.propertyName = name }
      if (t.sqlType == null) { t.sqlType = 12 }
      if (t.delimiter == null) { t.delimiter = "" }
      if (t.useValueOnly == null) { t.useValueOnly = "0" }
      // Create the property
      def type = MetadataObjects.PROPERTY
      def newProperty = (Property)factory.createComplexMetadataObject(mdObjectStore, null, name, type, reposId)
      println "New property \"${name}\" created."
      // Set values
      newProperty.with {
          setPropertyName t.propertyName
          setSQLType t.sqlType
          setDefaultValue defaultValue
          setUseValueOnly t.useValueOnly
      }
      println "Attributes set."
      if (!t.delimiter.equals("")) {
          newProperty.setDelimiter(t.delimiter)
      }

      return newProperty
   }

     Machine makeNewMachine(name) {
          def type = MetadataObjects.MACHINE
          def newMdObject = (Machine)factory.createComplexMetadataObject(mdObjectStore, null, name, type, reposId)
          return newMdObject
     }

     Directory makeDirectory(name) {
          def type = MetadataObjects.DIRECTORY
          def newMdObject = (Directory)factory.createComplexMetadataObject(mdObjectStore, null, name, type, reposId)
          return newMdObject
     }

     AuthenticationDomain makeAuthenticationDomain(name) {
          def type = MetadataObjects.AUTHENTICATIONDOMAIN
          def newMdObject = (AuthenticationDomain)factory.createComplexMetadataObject(mdObjectStore, null, name, type, reposId)
          return newMdObject
     }
    
     Login makeLogin(name) {
          def type = MetadataObjects.LOGIN
          def newMdObject = (Login)factory.createComplexMetadataObject(mdObjectStore, null, name, type, reposId)
          return newMdObject
     }    

     Property makeNewProperty(t, name, defaultValue) {
          // Named arguments: propertyName:"Text"
          if (t.propertyName == null) { t.propertyName = name }
          if (t.sqlType == null) { t.sqlType = 12 }
          if (t.propertyType == null) {
               if (t.sqlType == 4){
                    t.propertyType="Integer"
               } else {
                    t.propertyType="String"
               }
          }
          if (t.delimiter == null) { t.delimiter = "" }
          if (t.useValueOnly == null) { t.useValueOnly = "0" }
          // Create the property
          def type = MetadataObjects.PROPERTY
          def newProperty = (Property)factory.createComplexMetadataObject(mdObjectStore, null, name, type, reposId)
          println "New property \"${name}\" created with defaultValue \"${defaultValue}\" with PropertyName \"${t.propertyName}\" with delimiter \"${t.delimiter}\"."
          // Set values
          newProperty.with {
               setPropertyName t.propertyName
               setSQLType t.sqlType
               setDefaultValue defaultValue
               setUseValueOnly t.useValueOnly
          }
          println "Attributes set."
          if (!t.delimiter.equals("")) {
               newProperty.setDelimiter(t.delimiter)
          }
          // Owning Type
          type = MetadataObjects.PROPERTYTYPE
          def newPropertyType = (PropertyType)factory.createComplexMetadataObject(mdObjectStore, null, t.propertyType, type, reposId)
          println "New property type \"${t.propertyType}\" created."
          newPropertyType.setSQLType(t.sqlType)
          println "SQL Type set."
          if (t.propertyType.equals("Yes, No, or Blank Types")) {
               def text = mkYesNoBlankText()
               println "Text Store created."
               newPropertyType.setStoredConfiguration(text)
               println "Text Store added."
          } else if (t.propertyType.equals("Yes or No Types")) {
               def text = mkYesNoText()
               println "Text Store created."
               newPropertyType.setStoredConfiguration(text)
               println "Text Store added."
          } else if (t.propertyType.equals("Connection Types")) {
               def text = mkConnectionTypesText()
               println "Text Store created."
               newPropertyType.setStoredConfiguration(text)
               println "Text Store added."
        }
          newProperty.setOwningType(newPropertyType)
          println "Property Type added."
          return newProperty
     }

   void setThisProperty(name, propName, value, delim, properties, force=false)
   {
      if (((value != null) && (!value.equals(""))) | force)
      {
         def property = properties.find { it.getName().equals(name) }
         if (property != null)
         {
            (value == null) ? "" : value
            property.setDefaultValue(value)
         }
         else
         {
            property = makeNewProperty(name, value, propertyName:propName, delimiter:delim)
         }
         properties.add(property)
      }
      else
      {
         def property = properties.find { it.getName().equals(name) }
         if (property != null)
         {
            properties.remove(property)
            deleteObject(property)
         }
      }
   }

     TextStore mkYesNoBlankText() {
          def name = "Enumeration of Yes, No, or Blank"
          def textStore = makeTextStore(name)
          def storedText = "<Configuration>                <Enumeration>                    <Value name=\"\">Library.Common.Value.BlankNoValue.xmlKey.txt</Value>                    <Value name=\"YES\">Library.DBMS.Value.Yes.xmlKey.txt</Value>                    <Value name=\"NO\">Library.DBMS.Value.No.xmlKey.txt</Value>                 </Enumeration>             </Configuration>"
          textStore.with {
               setStoredText storedText
               setTextRole "config"
               setTextType "xml"
               setUsageVersion 0
          }
          return textStore
     }

     TextStore mkYesNoText() {
          def name = "Enumeration of Yes or No Types"
          def textStore = makeTextStore(name)
          def storedText = "<Configuration> <Enumeration>              <Value name=\"YES\">Library.DBMS.Value.Yes.xmlKey.txt</Value>             <Value name=\"NO\">Library.DBMS.Value.No.xmlKey.txt</Value>           </Enumeration> </Configuration>"
          textStore.with {
               setStoredText storedText
               setTextRole "config"
               setTextType "xml"
               setUsageVersion 0
          }
          return textStore
     }

     TextStore mkConnectionTypesText() {
          def name = "Enumeration of Connection Types"
          def textStore = makeTextStore(name)
          def storedText = "<Configuration> <Enumeration> <Value name=\"SHAREDREAD\">Library.DBMS.ConnectType.SharedRead.xmlKey.txt</Value> <Value name=\"GLOBALREAD\">Library.DBMS.ConnectType.GlobalRead.xmlKey.txt</Value> <Value name=\"UNIQUE\">Library.DBMS.ConnectType.Unique.xmlKey.txt</Value> <Value name=\"SHARED\">Library.DBMS.ConnectType.Shared.xmlKey.txt</Value> <Value name=\"GLOBAL\">Library.DBMS.ConnectType.Global.xmlKey.txt</Value> </Enumeration> </Configuration> "
          textStore.with {
               setStoredText storedText
               setTextRole "config"
               setTextType "xml"
               setUsageVersion 0
          }
          return textStore
     }

     /*  String getLASRSignerURL(host, port, user, password) {
      try { 
      Class c = Class.forName("com.sas.batch.localsvc.ScriptingLocalServicesContext")
      
      context = c.newInstance("LASRLibraryConfiguration");

      context.setConnection(host, port);
      context.setCredential(user, password);
      context.setUp();
      UserContextInterface usercontext = context.getUser();
      String signerURL = LASRServerUtil.getAuthorizationServiceUrl(usercontext);

      return signerURL;
     }catch(Exception e){
     println(e.message())
    }
     
   }*/

   Extension makeNewExtension(name, value) {
      def type = MetadataObjects.EXTENSION
      def newMdObject = (Extension)factory.createComplexMetadataObject(mdObjectStore, null, name, type, reposId)
      newMdObject.setValue(value)
      return newMdObject
   }

   void updateExtensionInAssocList(extensionName, extensionValue, assocListOfExtensions) {
      Boolean foundExtension = false

      for (Iterator it = assocListOfExtensions.iterator(); it.hasNext();)
      {
         Extension extension = (Extension)it.next();
         if (extension.getName().equals(extensionName))
         {
            foundExtension=true
            extension.setValue(extensionValue)
         }
      }

      if (false == foundExtension)
      {
         Extension newExtension = makeNewExtension(extensionName, extensionValue)
         assocListOfExtensions.add(newExtension)
      }

      return
   }
   
SASClientConnection getSASClientConnection(server, name) {
   def sConns = server.getSourceConnections()
   def sConn = sConns.find { it.getName() == name }
   return sConn
}


void setLibProperty(name, propName, value, delim, valueOnly, type, properties) {
   if ((value != null) && (!value.equals(""))) {
      def property = properties.find { it.getName().equals(name) }
      if (property != null) {
         (value == null) ? "" : value
         property.setDefaultValue(value)
      } else {
         property = makeNewProperty(name, value, propertyName:propName, delimiter:delim, useValueOnly:valueOnly, propertyType:type)
      }
      properties.add(property)
   } else {
      def property = properties.find { it.getName().equals(name) }
      if (property != null) {
         deleteObject(property)
      }
   }
}


void makeMBPPropertySet(lib) {
   def pSetName = "ModifiedByProductPropertySet"
   def pSet = makePropertySet(pSetName)
   pSet.setSetRole pSetName
   def pSets = lib.getPropertySets()
   pSets.add(pSet)
}

void setPreAssigned(isPreassigned, preAssignedType, lib){
   def name = "PreAssignedLibraryTypePanel.PreAssignedType.Name.txt"
   def propertyName = "PreAssignmentType"
   def pSetName = "PreAssignedLibrarySet"
   def pSets = lib.getPropertySets()
   pSets.each { println('INFO: PropertySet Name::'+it.getName()) }
   def pSet = pSets.find { it.getName().equals(pSetName) }
   
   
   if((pSet == null) && (isPreassigned == "1")) {
      pSet = makePropertySet(pSetName)
      pSets.add(pSet)
      def setProps = pSet.getSetProperties()
      def property = makeNewProperty(name, preAssignedType, propertyName:propertyName, delimiter:"=")
      setProps.add(property)
   } else if (pSet != null) {
      def setProps = pSet.getSetProperties()
      def property = setProps.find { it.getName().equals(name) }
      if (isPreassigned == "1") {
         if (property == null) {
            property = makeNewProperty(name, preAssignedType, propertyName:propertyName, delimiter:"=")
            setProps.add(property)
         } else {
            property.setDefaultValue(preAssignedType)
         }
      } else if (setProps != null) {
         if (property != null) {
            deleteObject(property)
         }
         deleteObject(pSet)
      }
   }
}

Property setAutoCommit(autoCommit) {
   def name = "Library.DBMS.Property.AUTOCOMMIT.Name.xmlKey.txt"
   def propName = "AUTOCOMMIT"
   def propType = "Yes or No Types"
   def property = makeNewProperty(name, autoCommit, propertyName:propName, propertyType:propType, delimiter:"=")
   return property
}


void updateSchemaName(libConnection, library, sComp, objectName, name) {
   def usingPackages = library.getUsingPackages()
   def schemaObject = usingPackages.find { it.getClass().getName() == "com.sas.metadata.remote.impl.DatabaseSchemaImpl" }

   if (schemaObject == null) {
      schemaObject = makeDbSchema(objectName, sComp, library)
   }

   if (libConnection == null) {
      // Tie schema to ServerComponent
      AssociationList dPackages = sComp.getDataPackages()
      dPackages.add(schemaObject)
   }
   schemaObject.setSchemaName name
}

DatabaseSchema makeDbSchema( _schemaObjectName, ServerComponent sComp, SASLibrary newLib) {
   def schema = makeDatabaseSchema(_schemaObjectName)
   // Tie schema to ServerComponent
   AssociationList dPackages = sComp.getDataPackages()
   dPackages.add(schema)
   // Tie schema to SASLibrary
   AssociationList uPackages = newLib.getUsingPackages()
   uPackages.add(schema)
   return schema
}



def setDbmsEngine(_serverDbms ){
def dbmsEngine
try{
   switch ( _serverDbms ) {
      case "oracle":
         dbmsEngine = "Oracle"
         break

      case "db2":
         dbmsEngine = "DB2"
         break

      case "teradata":
         dbmsEngine = "Teradata"
         break

      case "mysqldbs":
         dbmsEngine = "MYSQL"
         break

      case "greenplm":
         dbmsEngine = "GREENPLM"
         break

      case "postgres":
         dbmsEngine = "POSTGRES"
         break

      case "mssqlserver":
         dbmsEngine = "SQLSVR"
         break

      default:
        dbmsEngine=null
         break
   }
return dbmsEngine;
}
catch (Exception e) {
   println(e.getMessage())
   return
}

}


def createDBLib(_serverDbms,_serverName,_serverConnection,_serverContextName,_dbmsUserId,_serverDbName,_schemaName,libDesc,folderPath,libname=null,libref=null,libPropertyOptions=[:]) {
if (libname == null ){ libname=_schemaName }
if (libref == null ){ libref=_schemaName }
println("INFO: Executing createDBLib.")
println("INFO: Args : _serverDbms:$_serverDbms,_serverName:$_serverName,_serverConnection:$_serverConnection,_serverContextName:$_serverContextName,_dbmsUserId:$_dbmsUserId,_serverDbName:$_serverDbName,_schemaName:$_schemaName,libDesc:$libDesc,folderPath:$folderPath,libname:$libname,libref:$libref,libPropertyOptions:$libPropertyOptions")

if (_serverName == null) {
     _serverName=_serverDbms
 }
 
 if (libname == null || _serverDbms == null || _serverName == null || _serverConnection == null || _serverContextName == null || _dbmsUserId == null || _schemaName==null) {
  println("ERROR:: createDBLib:: Not all mandatory parameters are specified.")
  return 1
 }
 
def  _schemaObjectName          = _schemaName
def  _libname                   = libname
def  _libref                    = libref
def (_folderSearchPath)=getFolderSearchPath(folderPath)
def _libDesc=libDesc
println("INFO: Folder Path = $_folderSearchPath")

/*
def _serverDbms                 = "postgres"
def  _serverName                = "Risk Gov Frwk Data Server"
def  _serverConnection          = "Risk Governance Framework DB Conn for RGFDataServer"
def  _serverContextName         = "SASApp"
def  _dbmsUserId                = "rgfdbuser"
def  _serverDbName              = "rgfdbname"
def  _schemaName                = "mySchema"
def  _schemaObjectName          = "RGFTOOL"
def  _libname                   = "RGFTOOL"
def  _libref                    = _libname
def  _folderSearchPath          = "[@Name='RGFTOOL'][ParentTree/*[@Name='Data Sources']/ParentTree/*[@Name='SAS Risk Governance Framework']/ParentTree/*[@Name='Products']]"
*/

/* 
def _serverDbms      = "oracle"
def _serverName      = "Risk Governance Framework DB Server for Oracle"  //Find Connection from this  : dbuser abd dbname
def _serverConnection= "Risk Governance Framework DB Conn for Oracle"
def _serverName      ="Risk and Finance Workbench RDM DB Server for Oracle"
def _serverConnection="Risk and Finance Workbench RDM DB Conn for Oracle"
def _serverContextName= "SASApp"
def _dbmsUserId      = "rgfdbuser"
def _serverDbName    = ""
def _schemaName      = "schemaID"
def _schemaObjectName= _schemaName
def _libname= _schemaName
def _libref= _schemaName
*/
//def _folderSearchPath= "[@Name=\'${_schemaName}\'][ParentTree/*[@Name='Data Sources']/ParentTree/*[@Name='SAS Risk Governance Framework']/ParentTree/*[@Name='Products']]"




def _isPreassigned   = "1"
def _preAssignedType = "Native"
def _getTablesFolderSearchPath = ""
def _dbUpdateLockType= ""
def _dbcreatetableopts= ""
def _optionstring    = ""
def _dbmaxtext       = "4000"
def _insertBuff      = ""
def _readBuff        = ""
def _typeOfConnection= ""
def _sqlFunctions    = ""
def _preservecolnames= ""
def _preservetablenames        = ""
def _dbConinit       = ""
def _autoCommit      = ""
def _extraWhereClause= ""
def dbmsEngine=""


switch ( _serverDbms ) {
      case "oracle":
	  dbmsEngine = "Oracle"
     _dbUpdateLockType= ""
     _dbcreatetableopts= ""
     _optionstring    = "DB_LENGTH_SEMANTICS_BYTE=NO DBCLIENT_MAX_BYTES=1"
     _dbmaxtext       = "4000"
     _insertBuff      = "1000"
     _readBuff        = "1000"
     _typeOfConnection= ""
     _sqlFunctions    = ""
     _preservecolnames= "NO"
     _preservetablenames        = "NO"
     _dbConinit       = ""
     _autoCommit      = "YES"
     _serverDbName    = ""
     _extraWhereClause= "NO"
     break

      case "db2":
         dbmsEngine = "DB2"
         break

      case "teradata":
         dbmsEngine = "Teradata"
         break

      case "mysqldbs":
         dbmsEngine = "MYSQL"
         break

      case "greenplm":
         dbmsEngine = "GREENPLM"
         break

      case "postgres":
	  println("IN SWITCH")
        dbmsEngine = "POSTGRES"
       _getTablesFolderSearchPath = ""
       _dbUpdateLockType          = ""
       _dbcreatetableopts         = ""
       _optionstring              = ""
       _dbmaxtext                 = "4000"
      _insertBuff                = ""
      _readBuff                  = ""
      _typeOfConnection          = ""
      _sqlFunctions              = ""
      _preservecolnames          = "NO"
      _preservetablenames        = "NO"
      _dbConinit                 = ""
      _autoCommit                = "YES"
     _extraWhereClause          = ""

         break

      case "mssqlserver":
         dbmsEngine = "SQLSVR"
		_getTablesFolderSearchPath = ""
        _dbUpdateLockType          = ""
        _dbcreatetableopts         = ""
        _optionstring              = ""
        _dbmaxtext                 = "4000"
       _insertBuff                = ""
       _readBuff                  = ""
       _typeOfConnection          = "SHARED"
       _sqlFunctions              = ""
       _preservecolnames          = "NO"
       _preservetablenames        = "NO"
       _dbConinit                 = ""
       _autoCommit                = "YES"
       _extraWhereClause          = ""
	 
         break

      default:
        dbmsEngine=null
         break
   }
   



/*  Server Context*/
def serverContext = getServerContext(_serverContextName)
 /* Get the server component.*/
def sComp = getServerComponent(_serverName)
println('INFO:sComp :'+ sComp.getClass())

/* Get the SAS Client Connection.*/
 def clientConn = getSASClientConnection(sComp, _serverConnection)
 println('INFO:clientConn :'+ clientConn.getClass()) 
 
    // Default Login
   def defaultLogin
   if (!_dbmsUserId.equals("")) {
      // Get the Authentication Domain
      def authDomain = clientConn.getDomain()
      if (authDomain == null){
      println("ERROR:The AuthenticationDomain for the SASClientConnection, ${_serverConnection}, was not found.")
	  return 1
	        } else {
         println("INFO::The AuthenticationDomain for the SASClientConnection, ${_serverConnection}, was found.")
      }
      def domain = authDomain.getName()
      // Login
      defaultLogin = getLoginWithDomain(_dbmsUserId, domain)
      if (defaultLogin == null){
         println("ERROR:The Login for, ${_dbmsUserId}, was not found.")
		 return 1
      } else {
         println("INFO::The Login for, ${_dbmsUserId}, was found.")
      }
   }
   

  
  // No Updates  to SAS Library if it exists
   def lib = getSasLibrary(_libname)
   println('INFO::Lib:'+ lib.getClass())
   
   if ( lib == null) {
   println("INFO::Creating SAS Library, ${_libname}.")
      // Get the containing metadata folder.
       def folder = getMetadataFolder(_folderSearchPath)
      if (folder == null){
         println("ERROR:Folder search path: ${_folderSearchPath} not found.")
		 return 1
      } else {
         println("INFO::The required metadata folder was found: $folder")
      }
	  
	  
      // Create the Library
      def newLib = makeSasLibrary(_libname)
      println( "INFO:: newLib created with name ${_libname}.")
      newLib.with {
         setLibref _libref
         setEngine dbmsEngine
         setIsDBMSLibname 1
         setPublicType "Library"
         setUsageVersion 1000000
         // setDefaultLogin defaultLogin
         setLibraryConnection clientConn
         setIsPreassigned _isPreassigned
		 setDesc libDesc
      }
	  
      if (!_dbmsUserId.equals("")) {
         newLib.setDefaultLogin(defaultLogin)
      }
      AssociationList trees = newLib.getTrees()
      trees.add(folder)
      AssociationList dComponents = newLib.getDeployedComponents()
      dComponents.add(serverContext)
       
      // Make Modified By Product Property Set
      makeMBPPropertySet(newLib)
      // Make PreAssigned Library Property Set
      setPreAssigned(_isPreassigned, _preAssignedType, newLib)
       def properties = newLib.getProperties()
       if (!(_serverDbms.equals("greenplm") | _serverDbms.equals("teradata") | _serverDbms.equals("postgres"))) {
          setLibProperty("Library.DBMS.Property.UpdLockType.Name.xmlKey.txt", "UPDATE_LOCK_TYPE", _dbUpdateLockType, "=", "0", null, properties)
      }
       
       if (_serverDbms.equals("oracle")) {
         setLibProperty("Library.Oracle.Property.OR_UPD_NOWHERE.Name.xmlKey.txt", "OR_UPD_NOWHERE", _extraWhereClause, "=", "0", "Yes or No Types", properties)
      }
       setLibProperty("Connection.DBMS.Property.DB.Name.xmlKey.txt"           , "DATABASE"           , _serverDbName      , "=", "0", null, properties)
       setLibProperty("Library.DBMS.Property.DBCreateTabOpt.Name.xmlKey.txt"  , "DBCREATE_TABLE_OPTS", _dbcreatetableopts , "=", "0", null, properties)
       setLibProperty("Library.DBMS.Property.OtherOpt.Name.xmlKey.txt"        , "OptionString"       , _optionstring      , "" , "1", null, properties)
       setLibProperty("Library.DBMS.Property.DBMaxText.Name.xmlKey.txt"       , "DBMAX_TEXT"         , _dbmaxtext         , "=", "0", null, properties)
       setLibProperty("Library.DBMS.Property.SQL_FUNCTIONS.Name.xmlKey.txt"   , "SQL_FUNCTIONS"      , _sqlFunctions      , "=", "0", null, properties)
       setLibProperty("Library.DBMS.Property.PreserveColNames.Name.xmlKey.txt", "PRESERVE_COL_NAMES" , _preservecolnames  , "=", "0", "Yes, No, or Blank Types", properties)
       setLibProperty("Library.DBMS.Property.PreserveTabNames.Name.xmlKey.txt", "PRESERVE_TAB_NAMES" , _preservetablenames, "=", "0", "Yes, No, or Blank Types", properties)
       setLibProperty("Library.DBMS.Property.DBConInit.Name.xmlKey.txt"       , "DBCONINIT"          , _dbConinit         , "=", "0", null, properties)
       setLibProperty("Library.DBMS.Property.ConnType.Name.xmlKey.txt"        , "CONNECTION"         , _typeOfConnection  , "=", "0", "Connection Types", properties)
       setLibProperty("Library.DBMS.Property.InsertBuff.Name.xmlKey.txt"      , "INSERTBUFF"         , _insertBuff        , "=", "0", null, properties)
       setLibProperty("Library.DBMS.Property.ReadBuff.Name.xmlKey.txt"        , "READBUFF"           , _readBuff          , "=", "0", null, properties)
	   
	   //Code Block to add custom properties to library 
	    
	    def error_cd=0
	    libPropertyOptions.find { 
		   println("INFO::createDBLib:: Library Property Options :: "+ it)
		   if (it.key == 'DIRECT_EXE') { 
		   setLibProperty(it.name?:"Library.DBMS.Property.DirectExe.Name.xmlKey.txt" , it.key , it.defaultValue , it.delimiter?:"=", it.useValueOnly?:"0", it.type?:null,properties)
		   } else if (it.key == 'DIRECT_SQL') { 
		      setLibProperty(it.name?:"Library.DBMS.Property.DirectSql.Name.xmlKey.txt" , it.key , it.defaultValue , it.delimiter?:"=", it.useValueOnly?:"0", it.type?:null,properties) 
		   } else if (it.key == 'DBMAX_TEXT') { 
		      setLibProperty(it.name?:"Library.DBMS.Property.DBMaxText.Name.xmlKey.txt" , it.key , it.defaultValue , it.delimiter?:"=", it.useValueOnly?:"0", it.type?:null,properties) 
		     }else { 
			    if ( it.name && it.defaultValue ) { 
			    setLibProperty(it.name, it.key , it.defaultValue , it.delimiter?:"=", it.useValueOnly?:"0", it.type?:null,properties)
				}else { 
				   println("ERROR::createDBLib:: "+it.key+" Property name or its default value not specified.") 
				   error_cd=1
				   return true
				}
			 
			 }
			
		  }
      //Failing if libPropertyOptions options are not set well. 
		  if (error_cd == 1) { 
		    return 1
		  }
		  
        
        if (_serverDbms.equals("mysqldbs")) {
         if (!_autoCommit.equals("YES")) {
            def property = setAutoCommit(_autoCommit)
            properties.add(property)
         } else {
            def property = properties.find { it.getName() == "Library.DBMS.Property.AUTOCOMMIT.Name.xmlKey.txt" }
            if (property != null) {
               deleteObject(property)
            }
         }
      }
      println("INFO::newLib properties set for ${_libname}.")
      def schema = makeDbSchema( _schemaObjectName, sComp, newLib)
      schema.setSchemaName("\"${_schemaName}\"")
      // If we need to get tables from a folder.
      if (!_getTablesFolderSearchPath.equals("")) {
         // Get the metadata folder containing the tables.
         def tablefolder = getMetadataFolder(_getTablesFolderSearchPath)
         if (tablefolder == null){
            println("INFO::Folder search path: ${_getTablesFolderSearchPath} not found.")
            
         } else {
            println("INFO::The required metadata folder was found.")
         }
         def tables = tablefolder.getMembers().findAll { it.getPublicType() == "Table" }
         if (tables.size() > 0) {
            def schemaTables = schema.getTables()
            schemaTables.addAll(tables)
         }
      }
       newLib.updateMetadataAll()
	   } else {
	   println("NOTE:Library ${_libname} already exists.")
	   }
        

}



/* TOD In progress*/
Tree makeFolder(parent,name) {
          def type = MetadataObjects.TREE
		  
          def newMdObject = (Tree)factory.createComplexMetadataObject(mdObjectStore, name, type, reposId)
		  //newMdObject.setPublicType("Folder")
          //newMdObject.setUsageVersion("1000000")
		  //newMdObject.setTreeType("BIP Folder")
		 
		  //newMdObject.updateMetadataAll()
		  return newMdObject
     }
	 
	 

	 
/**
 * Returns Assolication List & Vector holding softwareComp attributes object that can then be used to query or update metadata.  println("prop ::"+ it + "::"+it.getDefaultValue() )
 *
 * @param  softCompName  SoftwareComponentName 
 * @param   Type : Defaults to Name or we can use ClassIdentifier
 * @return      [Vector,AssolicationList] 
 */
def findSWCProperties(softCompName,type='Name') {
           def xmlSelect = "<XMLSELECT Search=\"SoftwareComponent[@$type='"+softCompName+"'\"/>"
           def app=findMetadataObjects('SoftwareComponent',xmlSelect)
           return [app.firstElement().getPropertySets().firstElement().getSetProperties(),app]
		   
	}
	
	
	/**
 * Returns Assolication List & Vector holding softwareComp attributes object that can then be used to query or update metadata.  println("prop ::"+ it + "::"+it.getDefaultValue() )
 *
 * @param  softCompName  SoftwareComponentName
 * @return      [Vector,AssolicationList] 
 */
def findSWCPropertiesFromClassId(classId) {
           def xmlSelect = "<XMLSELECT Search=\"SoftwareComponent[@ClassIdentifier='"+classId+"'\"/>"
           def app=findMetadataObjects('SoftwareComponent',xmlSelect)
           return [app.firstElement().getPropertySets().firstElement().getSetProperties(),app]
		   
	}

	
	
/* Function to find server context name based on software component name. Usually it is SASApp by default. */

def getAppServerName(softCompName,type='Name') {
/* From framework below code is unreachable but when we use it separately this can happen. */
  if (softCompName == null || softCompName=='') {
	  softCompName='vacommon'
	  type='ClassIdentifier'
	 }

	
	println("INFO: Function :: getAppServerName::Component Name" + softCompName + '::Type::'+type)
	def serverContextName=null
	def xmlSelect = "<XMLSELECT Search=\"SoftwareComponent[@$type='"+softCompName+"'\"/>"
	def app=findMetadataObjects('SoftwareComponent',xmlSelect)
	if (app.isEmpty()) {
	  println("WARNING: Function :: getAppServerName::Software Component Name::" + softCompName + ' not found.')
	  return null
	}
		
	println("INFO:SoftwareComponent ::"+app.firstElement().getSoftwareVersion() + "::" + app.getClass())
	def assoc=app.firstElement().getDependsOnComponents()
	assoc.each {
		println("NOTE:Dependent Component Class ::" + it.getClass().toString() + "Type ::" + it.getName())
		if (it.getClass().toString().contains('ServerContext')) {
		  	  serverContextName=it.getName()
		 }
		
	   }
	 if (serverContextName != null ) {
		 println("NOTE:Found ServerContext for Software Component :: $softCompName" )
		 return serverContextName
	 }else {
		 
		 println("ERROR:ServerContext Name not found for Software Component :: $softCompName")
	 }  
	
	 return serverContextName
	 
} 
	


def getFolderSearchPath(folderPath) {

def arr=folderPath.split("/")
arr[0]=null
def leaf=arr[arr.size()-1]
arr[arr.size()-1]=null
def str1=''
arr.each {
if (it != null){
str1="ParentTree/*[@Name=\'$it\']"+"/"+str1
}
}
if (str1 != "") {
str1="[@Name=\'$leaf\']["+str1+"]"
}else {
str1="[@Name=\'$leaf\']"
}
println("INFO getFolderSearchPath:: Leaf folder IS $leaf");
def folderSearchPath=str1.replaceAll(~/]\/]/, "]]")
return [folderSearchPath,leaf]
}


def setAuthOnObj() {
     
def omiConnection = omrConnection.getCMRHandle();
ISecurityAdmin iSecAdmin = ISecurityAdminHelper.narrow(omiConnection);
if (iSecAdmin == null) {
  println("ERROR: could not implement ISecurityAdmin API");
 }else {
      
      println(iSecAdmin.getClass())
 }


}



/**
 * Creates Base SAS library 
 *
 * @param  _serverContextName  ServerContextName like SASApp (can be diff based on env. There is another funtion to get the actual one from software component) 
 * @param   libname : Library Name
 * @param   libDesc : Library Description.
 * @param   libref : Library Reference.
 * @param   metadataFolderPath : Folder Path in Metadata where you want to create library : /SharedData/test.
 * @param   libPhysicalPath : Physical Path point to OS location.
 * @param   engineType :Defaults to BASE.
 * @param   _isPreassigned :Defaults to 1 (meaning we want to preassign it).
 * @param   _preAssignedType : Pre-Assigned TypeDefaults  to Native.
 * @return   0 on success. 1 : if library already exist. >=2 any failures.
 */
 
def createBaseSASLib(_serverContextName,libname,libDesc,libref,metadataFolderPath,libPhysicalPath,engineType='BASE',_isPreassigned=1,_preAssignedType='NATIVE') {
println("INFO: Executing CreateBASELib.")
println("INFO: Args : _serverContextName:$_serverContextName,libname:$libname,libDesc:$libDesc,metadataFolderPath:$metadataFolderPath,libPhysicalPath:$libPhysicalPath,libref:$libref,engineType:$engineType")
if (_serverContextName == null || libname == null || libDesc == null || libref == null || libPhysicalPath == null ) { 
println("ERROR: CreateBASELib : Not all mandatory parameters are provided.")
return 2;
}

def  _libname                   = libname
def  _libref                    = libref
def (_folderSearchPath)=getFolderSearchPath(metadataFolderPath)
def _libDesc=libDesc
println("INFO: Folder Path = $_folderSearchPath")
def _getTablesFolderSearchPath = ""
/*  Server Context*/
def serverContext = getServerContext(_serverContextName)
  
// No Updates  to SAS Library if it exists
   def lib = getSasLibrary(_libname)
   println('INFO::Lib:'+ lib.getClass())
   
   if ( lib == null) {
   println("INFO::Creating SAS Library, ${_libname}.")
      // Get the containing metadata folder.
       def folder = getMetadataFolder(_folderSearchPath)
      if (folder == null){
         println("ERROR:Folder search path: ${_folderSearchPath} not found.")
		 return 2
      } else {
         println("INFO::The required metadata folder was found: $folder")
      }
	  
      // Create the Library
      def newLib = makeSasLibrary(_libname)
      newLib.with {
         setLibref _libref
         setEngine engineType
         setIsDBMSLibname 0
         setPublicType "Library"
         setUsageVersion 1000000
         setIsPreassigned _isPreassigned
		 setDesc libDesc
      }
	  
	  //Code for adding parent tree to library
      AssociationList trees = newLib.getTrees()
      trees.add(folder)
      AssociationList dComponents = newLib.getDeployedComponents()
      dComponents.add(serverContext)
      AssociationList treesDir = newLib.getUsingPackages()
	  def newDir=makeDirectory('Path')
	  newDir.with { 
	   setUsageVersion 1000000
	   setDirectoryName libPhysicalPath
	   setDirectoryRole 'LibraryPath'
	   }
	   treesDir.add(newDir)
	   
	  // Make Modified By Product Property Set
      //makeMBPPropertySet(newLib)
	  
      // Make PreAssigned Library Property Set
      setPreAssigned(_isPreassigned, _preAssignedType, newLib)
	  newLib.updateMetadataAll()
	  println( "INFO:: New Base SAS Lib created with name ${_libname}.")
	  return 0
	   } else {
	   println("NOTE:Base SAS Library ${_libname} already exists.")
	   return 1
	   }
        

}



}

new MetadataUtilityClassInternal();
