import com.sas.metadata.MdObjectFactory;
import com.sas.metadata.MetadataUtil;
import com.sas.metadata.MetadataWorkspace;

class JomaWrapperInternal {
	def ant = new AntBuilder();
	def host = "";
	def port = "";
	def user = "";
	def password = "";
	def repositoryStr = "";
	def workspace = null;
	def connection = null;
	def reposFQID = null;
	def reposId = null;
	def objStore = null;

	void connect(host, port, user, password, repositoryStr) {
		this.host = host;
		this.port = port;
		this.user = user;
		this.password = password;
		this.repositoryStr = repositoryStr;

		println( "Connecting to metadata server:");
		println( "    Host: " + host);
		println( "    Port: " + port);
		println( "    User: " + user);

		// Enable/Disable print of xml between client and server
		MdObjectFactory.getInstance().setLoggingEnabled(false);

		// Connect to the metadata server
		workspace = MetadataWorkspace.getWorkspace();
		connection = workspace.makeOMRConnection(host, port, user, password);
		workspace.setCMRHandle(connection);

		println( "Connected to metadata server");

		// Get the repository information
		reposFQID = null;
		reposId = null;
		def repositories = MetadataUtil.getRepositories();
		for (def it = repositories.iterator(); it.hasNext();) {
			def repos = it.next();
			if (repositoryStr.equals(repos.getName())) {
				reposFQID = repos.getFQID();
				reposId = reposFQID.substring(reposFQID.indexOf(".")+1);
				println( "Found repository: " + repositoryStr + " id: " + reposFQID);
			}
		}

		if (reposFQID == null || reposId == null) {
			println( "Error finding repository named: " + repositoryStr);
		}

		// Create the joma object store
		objStore = MdObjectFactory.createObjectStore();
	}

	void disconnect() {
		// Disconnect from the metadata server
		workspace.closeOMRConnection();
	}

	def getMetadataObjects(type, search) {
		 def xmlSelect = "<XMLSelect search=\"" + type + "[" + search + "]\" />";
		//def xmlSelect = "<XMLSelect search=\"${search}\"/>";
		println( "Searching for metadata");
		println( "    Type: " + type);
		println( "    Search: " + xmlSelect);

		def objects = MetadataUtil.getMetadataObjectsSubset(objStore,
				reposFQID,
				type,
				MetadataUtil.OMI_XMLSELECT |
				MetadataUtil.OMI_ALL_DESCENDANTS |
				MetadataUtil.OMI_TEMPLATE |
				MetadataUtil.OMI_GET_METADATA|
				MetadataUtil.OMI_INCLUDE_SUBTYPES
				,
				xmlSelect);




		println("Found metadata count: " + objects.size() );
		for (def it = objects.iterator(); it.hasNext(); ) {
			def obj = it.next();
			println("Name: " + obj.getName());
		}

		return objects;
	}

	def getMetadataObject(type, searchStr) {
		def retval = null;

		def objects = getMetadataObjects(type, searchStr);
		if (objects != null && objects.size() > 0) {
			retval = objects.get(0);
		}

		return retval;
	}

	def newMetadata(name, type) {
		return MdObjectFactory.createComplexMetadataObject( getObjStore(),
				name,
				type,
				getReposId());
	}

	boolean isConnected() {
		return (workspace != null);
	}



}

new JomaWrapperInternal();

