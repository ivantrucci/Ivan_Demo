
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import org.apache.poi.xssf.usermodel.XSSFRow
import org.apache.poi.xssf.usermodel.XSSFSheet
import org.apache.poi.xssf.usermodel.XSSFCell
import org.apache.poi.ss.usermodel.Workbook
import org.apache.poi.ss.usermodel.Sheet
import org.apache.poi.ss.usermodel.Cell
import org.apache.poi.ss.usermodel.Row
import java.nio.file.FileSystems
import groovy.io.FileType
import java.io.FileInputStream
import java.io.*
import java.util.logging.Level
import java.util.logging.Logger
import java.util.logging.ConsoleHandler

class ExcelUtilInternal {
	
	 
	private static final Logger logger = Logger.getLogger(ExcelUtilInternal.class.getName());
	
	def setLogLev(logLevel=Level.INFO) {
		println("LOG LEVEL ::"+logLevel)
		logger.setLevel(logLevel)
		ConsoleHandler handler = new ConsoleHandler()
		// PUBLISH this level
		handler.setLevel(logLevel)
		logger.addHandler(handler)
		//Disabling the global logger so that we don't get messages duplicated
		logger.setUseParentHandlers(false)
		println("##LOG LEVEL ::"+handler.getLevel()+"##")
		
	}

	
	/*readMapFile: takes file and return a map of the first 2 columns of the file
	 adds first column as key and 2nd coliumn as value.*/
	def readMapFile(String file,String sheetName) {
		println "File to read is" + file;
		Workbook wb = new XSSFWorkbook(new FileInputStream(file));
		Sheet sheet =null;
		/* checking sheetName is blank or not if blank we just get the first sheet*/
		if (sheetName == "") {
			sheet = wb.getSheetAt(0);
		}else {
			sheet = wb.getSheet(sheetName);
		}

		/* getting total rows in sheet so that we can loop */
		println("INFO:Total rows " + sheet.getLastRowNum());
		/*def tempMap=[:];*/
		Map<String, String> tempMap =
		new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);

		for (def i = 1; i <= sheet.getLastRowNum(); i++) {
			def tempRow=sheet.getRow(i);
			def keyCell=tempRow.getCell(0).toString();
			def valueCell=tempRow.getCell(1).toString();
			tempMap[keyCell]=valueCell;
		}


		return tempMap;
	}


/**
 * Works as search and replace in all sheets of workbook. If you have map of key value pairs you can use it to update cells in excel. 
 * @map : Map of key value pairs
 * @xlsxFile : Source Workbook
 * @OutFile : Workbook to write to. 
 */

	def updateXlsxUsingMap(Map map,String xlsxFile,String outFile){
		println("INFO:Input XLSX File" + xlsxFile)
		Workbook wb = new XSSFWorkbook(new FileInputStream(xlsxFile));
		/*Sheet sheet = wb.getSheet(sheetName);*/
		println "TOTAL SHEETS ::" + wb.getNumberOfSheets();
		for (int i = 0; i < wb.getNumberOfSheets(); i++) {
			Sheet sheet = wb.getSheetAt(i);
			println "Processing Sheet :: "+ wb.getSheetName(i);
			Row row=sheet.getRow(0);
			for (Cell cell : row) {
				if (map.containsKey(cell.toString())) {
					/* println "----"+ cell.toString() + "::" + map.get(cell.toString());*/
					println "---" + sheet.getSheetName() +"::" + "header field::" + map.get(cell.toString());
					cell.setCellValue(map.get(cell.toString()));
				}
			}
		}
		/*outFile=xlsxFile+'_out.xlsx';*/
		println("INFO: Writing updated columns to:" + outFile);
		FileOutputStream fileOut = new FileOutputStream(outFile);
		//write this workbook to an Outputstream.
		wb.write(fileOut);
		fileOut.flush();
		fileOut.close();
	}

/**
 * Reads xlsx file and stores the first 2 column valuesin MAP and returns the MAP.
 * @configFile : Workbook xlsx file to read.
 * @sheetName : Name of sheet to read.
 */
	def readConf(String configFile, String sheetName){
		println("INFO:Config file to look for adding columns" + configFile)
		def arr=[];
		Workbook wbConfig = new XSSFWorkbook(new FileInputStream(configFile))
		Sheet sheetConfig = wbConfig.getSheet(sheetName);
		Row rowConfig1=sheetConfig.getRow(0);

		for (int i=1 ; i<=	sheetConfig.getLastRowNum();i++) {
			Row rowConfig=sheetConfig.getRow(i);
			Map<String, String> tempMap = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
			for (int j=0 ; j<	rowConfig.getLastCellNum();j++) {
				/*println "KEY:: " + rowConfig1.getCell(j).toString() + " VALUE:: " + rowConfig.getCell(j).toString();*/
				tempMap.put(rowConfig1.getCell(j).toString(),rowConfig.getCell(j).toString());
			}
			arr.push(tempMap);
		}
		return arr;
	}


	def addColumnAndValue(String xlsxFile, List list){
		println "Adding columns to xlsxFile" + xlsxFile;
		Workbook wb= new XSSFWorkbook(new FileInputStream(xlsxFile));
		list.each {
			def columnIndex=null;
			/*println "Looking at sheet " + it.getAt('DATALOAD_SHEET') + " and column " + it.getAt('ADD_COLUMN');*/
			Sheet sheet = wb.getSheet(it.getAt('DATALOAD_SHEET'));
			Row row=sheet.getRow(0);
			for (int j=0 ; j<row.getLastCellNum();j++) {
				/*println row.getCell(j).toString() + "-- " + it.getAt('ADD_COLUMN');*/
				if (row.getCell(j).toString()== it.getAt('ADD_COLUMN')){
					println "COLUMN  " + it.getAt('ADD_COLUMN') + " exists in sheet " + it.getAt('DATALOAD_SHEET') ;
					columnIndex=j;
					break;
				}
			}

			if (columnIndex == null ) {
				println "ADDING COLUMN " + it.getAt('ADD_COLUMN') + " to sheet " + it.getAt('DATALOAD_SHEET') ;
				def maxColIx = row.getLastCellNum();
				Cell cell=row.createCell(maxColIx);
				cell.setCellValue(it.getAt('ADD_COLUMN'));
				columnIndex=maxColIx;
			}



			for (int i=1 ; i<=	sheet.getLastRowNum();i++) {

				Row row1=sheet.getRow(i);
				Cell cell1=row1.createCell(columnIndex);
				if (it.getAt('VALUE') == 'null') {
					value="";
				}else {
					value=it.getAt('VALUE');
				}
				println "ColumnIndex " + columnIndex + " " + value;
				cell1.setCellValue(value);
			}
		}


		FileOutputStream fileOut = new FileOutputStream(xlsxFile);
		wb.write(fileOut);
		fileOut.flush();
		fileOut.close();
		println "Added/updated columns to " + xlsxFile;
	}



/**
 * Used to prepend some text to all values of a column.
 * 
 * 
 */
	def prependTextToXlsx(inpXlsxFile,inpXlsxFileSheetNm,inpXlsxFileSheetColNm,prependText,outxlsxFile) {
		Workbook wb1= new XSSFWorkbook(new FileInputStream(inpXlsxFile))
		Sheet sheet1 = wb1.getSheet(inpXlsxFileSheetNm)
		Row row1=sheet1.getRow(0)
		def columnIndex=-99
		/* Identifying first column index */
		for (int j=0 ; j<row1.getLastCellNum();j++) {
			println(row1.getCell(j).toString())
			if (row1.getCell(j).toString().equalsIgnoreCase(inpXlsxFileSheetColNm) ){
				println("INFO:Column ${inpXlsxFileSheetColNm} exists in sheet ${inpXlsxFileSheetNm}")
				println('INFO:Found column'  + columnIndex)
				columnIndex=j;
				break;
			}
		}
		/* Once column index identified we find corresponding cell for prepend text */
		if (columnIndex >= 0) {
		
			for (int k = 1; k <= sheet1.getLastRowNum(); k++) {
				def path=prependText+sheet1.getRow(k).getCell(columnIndex).toString()
				Cell cell=sheet1.getRow(k).createCell(columnIndex)
				cell.setCellValue(path)
			}
			FileOutputStream fileOut = new FileOutputStream(outxlsxFile)
			wb1.write(fileOut)
			fileOut.flush()
			fileOut.close()
			println("Note: updated columns to " + outxlsxFile)
		}
	}
}
new ExcelUtilInternal()
