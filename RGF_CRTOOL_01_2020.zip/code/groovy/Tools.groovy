import org.apache.tools.ant.Project
import org.apache.tools.ant.ProjectHelper
import org.apache.tools.ant.DefaultLogger
import com.sas.tools.webappconfig.tasks.*
import com.sas.services.webdav.WebDAVDump
import com.sas.services.webdav.WebDAVRestore
import com.sas.services.webdav.DAVResource
import com.sas.services.webdav.*
import groovy.util.XmlSlurper
import java.nio.file.Files
import java.nio.file.Paths
import java.nio.file.Path
import java.nio.file.FileSystems;
import java.nio.file.attribute.BasicFileAttributes
import java.util.logging.Logger
import java.util.logging.Level
import java.util.logging.ConsoleHandler
import java.util.regex.Matcher
import java.util.regex.Pattern
import groovy.io.FileType;
import org.codehaus.groovy.runtime.StackTraceUtils
/* import com.sas.workflow.util.checkin.WorkflowLoader
 import com.sas.workflow.* */
import java.io.InputStream
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import org.apache.poi.xssf.usermodel.XSSFRow
import org.apache.poi.xssf.usermodel.XSSFSheet
import org.apache.poi.xssf.usermodel.XSSFCell



public class ToolsInternal {
     def basePath=null
     def basePathContent=null
     def debug=false
      
     def Logger logger = Logger.getLogger(ToolsInternal.class.getName());
     
     def setLogLev(logLevel=Level.INFO) {
          println("LOG LEVEL ::"+logLevel)
          logger.setLevel(logLevel)
          ConsoleHandler handler = new ConsoleHandler()
          // PUBLISH this level
          handler.setLevel(logLevel)
          logger.addHandler(handler)
          //Disabling the global logger so that we don't get messages duplicated
          logger.setUseParentHandlers(false)
          println("##LOG LEVEL ::"+handler.getLevel()+"##")
          
     }


     def setBasePath(basePath,basePathContent,debug=false) {
          this.basePath=basePath
          this.basePathContent=basePathContent
          this.debug=debug

     }


     def debug(msg) {
          if (debug){
               println("DEBUG:"+msg)
          }
     }

     def ToolsInternal() {
          println("############You are in Tools Class#################")
     }


     def  runCmdLine(commandToExecute,workingDirPath,fileNameWithPathforstdin=null) {

          println("NOTE:Executing Command ::"+commandToExecute)
          println("NOTE:Working Dir ::"+workingDirPath)
          println('NOTE:STDIN file::'+fileNameWithPathforstdin)

          def env = System.getenv()
          def envlist = [];
          env.each() {
               k,v -> envlist.push( "$k=$v" )
          }
          
          def workdir=new File(workingDirPath);
          if (! workdir.exists()) {
               println('ERROR::'+workingDirPath+" doesn't exist")
          }
          try {
               ProcessBuilder pb=new ProcessBuilder()
               pb.redirectErrorStream(true);
               pb.command(commandToExecute)
               pb.directory(workdir)
               //println('Working DIr:::'+pb.directory())
               if (fileNameWithPathforstdin != null){
                    def stdInFile=new File(fileNameWithPathforstdin)
                    pb.redirectInput(stdInFile)
               }
               Process process=pb.start()
               BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()))
               def s
               while ((s = stdInput.readLine()) != null) {
                    println(s);
               }
               process.waitFor()
               return process.exitValue()
          } catch (Exception e) {
               e.printStackTrace()
          }

     }



     def setUpAntProject(sasConfLev,antbuildFile,sasadmpass,midtierHost,midtierPort,protocol,sasadmuser='sasadm@saspw',tmpDir='_tmp',webappsrv_container_type='vfabrictcsvr') {
          println("############In setUpAntProject##########")
          if (tmpDir == '_tmp' ) {
               def currentDir=new File(".")
               def cwd=currentDir.getCanonicalPath()
               def tmpDirHandle=new File(cwd+'/_tmp')
               tmpDirHandle.mkdirs()
               tmpDir=tmpDirHandle.getCanonicalPath()
          }
          println("TEMP_DIR::"+tmpDir)
          System.setProperty('temp.dir',tmpDir)

          def levelEnvFile=sasConfLev+"/level_env.sh"
          if (System.properties['os.name'].toLowerCase().contains('windows')) {
               levelEnvFile=sasConfLev+"/level_env.bat"
          }

          def map=readCmdShFile(levelEnvFile)
          if (! map.get('UTILITIES') ||  ! map.get('DEPLOYWIZ')) {
               println("NOTE:Could not find properties : UTILITIES & DEPLOYWIZ")
               return
          }
          if (map.get('SASROOT')) {
            println("NOTE:Found SASROOT : " + map.get('SASROOT'))
            System.setProperty("SASROOT", map.get('SASROOT'))
          }
          
          
          if (map.get('SAS_HOME')) {
            println("NOTE:Found SAS_HOME : " + map.get('SAS_HOME'))
            System.setProperty("SAS_HOME", map.get('SAS_HOME'))
          }
          

          System.setProperty("install.cfgwizard.utilities.dir", map.get('UTILITIES'))
          System.setProperty("SASCONFIG", sasConfLev)
          System.setProperty("default.groovy.path",map.get('DEPLOYWIZ') )
          System.setProperty("12byte.groovy.path", map.get('DEPLOYWIZ'))
          System.setProperty('iomsrv.httpserver.protocol.type',protocol)
          System.setProperty('iomsrv.httpserver.host',midtierHost)
          System.setProperty('iomsrv.httpserver.port',midtierPort)
          System.setProperty("oma.person.admin.login.userid", sasadmuser)
          System.setProperty("oma.person.admin.login.passwd", sasadmpass)
          System.setProperty("metadata.connection.userid", sasadmuser)
          System.setProperty("metadata.connection.passwd",sasadmpass)
          System.setProperty("oma.person.trustusr.login.userid", sasadmuser)
          System.setProperty("oma.person.trustusr.login.passwd", sasadmpass)
          System.setProperty("webappsrv.container.type", webappsrv_container_type)
          System.setProperty("configuration.properties.file",sasConfLev+"/Utilities/cfgwizard.configuration.properties")
          System.setProperty("webapp.auto_deploy", 'true')
          System.setProperty("console.mode.is_enabled", 'true')
          /* System.setProperty("ant.file", "\\\\sashq\\root\\dept\\risk\\oprisk\\mrm_post_install_scripts\\MRMPostInstall\\migration_utils\\Cr_tool\\mrm_config.xml")*/
          /* def antBuildFilePathAndName = "\\\\sashq\\root\\dept\\risk\\oprisk\\mrm_post_install_scripts\\MRMPostInstall\\migration_utils\\Cr_tool\\mrm_config.xml"*/
          def antFile = new File(antbuildFile)
          def project = new Project()
          def consoleLogger = new DefaultLogger()
          consoleLogger.errorPrintStream = System.err
          consoleLogger.outputPrintStream = System.out
          consoleLogger.messageOutputLevel = Project.MSG_INFO
          project.addBuildListener(consoleLogger);

          project.init()
          ProjectHelper.projectHelper.configureProject(project, antFile)
          println("NOTE:ProjectName:: "+project.getName())
          /*def hash=project.getTargets()
           hash.each {
           println('Target Key::'+it.getKey()+"::Target Name::::"+it.getValue())
           }*/



          return project;

          /*  exampleUsage
           def prj=setUpAntProject("C:/SAS/Config/Lev1","Y:/mrm_config.xml")
           prj.executeTarget('uploadNotification')*/
     }




     public static getCurrentMethodName(){

          return Thread.currentThread().getStackTrace()[2].getMethodName()
     }


     def readCmdShFile(fileNamewithPath) {
          def tempMap=[:]
          new File(fileNamewithPath).getText('UTF-8').eachLine {
               line ->
               def m
               if ((m = line =~ /^(SET|export)?(.*)\=(.*$)/)) {
                    debug(m.group(2).trim()+"="+m.group(3).trim())
                    tempMap.put(m.group(2).trim(),m.group(3).trim())
               }
          }

          return tempMap
     }




     DAVResource  getWebDavResource(url,user,password) {
          ConnectionInfo c = new ConnectionInfo(url, user, password)
          return new DAVResource(c)
     }

     def dumpWebDav(resource,fileDir) {
         println("INFO : Importing DAV content into : "+fileDir)
          File currentDir = new File(fileDir)
          if( currentDir.exists() ) {
               println("Deleting dir first::"+fileDir)
               currentDir.deleteDir()
          }
          currentDir.mkdirs()
          WebDAVDump.dumpResource(resource,currentDir)
          resource.close()
     }

     def restoreWebDav(resource,fileDir,replace=false) {
          println('replace='+replace)
          File restoreDir = new File(fileDir)
          if( restoreDir.exists() ) {
               WebDAVRestore.replace=replace
               WebDAVRestore.restore(resource,restoreDir)
          }
          resource.close()
     }



     def getWebDavFile(resource,filewithPath) {
          def type=resource.getContentType()
          File fileHandle=new File(filewithPath)
          resource.getContents(fileHandle)
          /* println("type:"+type)*/
     }

     def setWebDavFile(resource,filewithPath) {
          Path path = Paths.get(filewithPath);
          byte[] data = Files.readAllBytes(path);
          resource.setContents(data)
          println("NOTE:File updated to content server:: "+resource.getPath())
     }
	 
	 
/**
* 
* The webDavFileOperation functions implements Copy/Move/Operations of files/folders on content server.  
* For delete operation you don't need toDavUrl. For any folder copy or move or delete do not provide pattern argument.
* This function internally uses : getWebDavResource. 
* 
* @param action : Defaults to  null. Permissible values : copy/move/delete : case sensitive.
* @param baseUrl : Midtier base URL Example : http(s)://midtierhost:7980/ .
* @param user : User with full access to content server : usually SAS Administrator.
* @param password : User password.
* @param fromDavUrl : Dav URL path to look for files or collection/folder
* @param pattern : allows you to filter files fron fromDavUrl : you need regex  like  1> ^.*(foo.json|foo.sas)  2. ^.*.sas (all sas files). 
* @param toDavUrl : Target Dav URL path only applicable to copy/move.
*
* @return void 
*
*/

     void webDavFileOperation(action=null,baseUrl,user,password,fromDavUrl,pattern=null,toDavUrl) {
	       
	    if (action && user && password && fromDavUrl ) { 
		println("INFO: We are proceeding all the required parameter present.") 
		action=action.toLowerCase()
		}else {
		println("ERROR: Required parameter present missing : check arguments : action , fromDavUrl. ") 
		return null;
		}
		
		println("NOTE:Content Server URL::" + "${baseUrl}/"+fromDavUrl) 
		 
		def res=getWebDavResource("${baseUrl}/"+fromDavUrl, user, password)		
		if (! res.SUCCEEDED()) { 
		println("ERROR: Cannot connect to fromDavUrl.")
        return null; 		
		}
		
		println("INFO:Connection to resource fromDavUrl status:"+res.getStatusCode() + ": Pattern: "+pattern)
		   
		  if (res.SUCCEEDED() && pattern) {
		     def children=res.getChildrenList(fromDavUrl)
			 def childrenMatchingPattern=children.grep(~/${pattern}/)
			 println("INFO::List of Files matched in ${fromDavUrl}::" + childrenMatchingPattern)
			 if (children.size() > 0 && childrenMatchingPattern.size() > 0) { 
			   childrenMatchingPattern.each {  file -> 
			   def fileName=Paths.get(file).getFileName()
			   def tmpResult = getWebDavResource("${baseUrl}/"+file, user, password)
			     try {
				      if (action == 'delete') { 
			          tmpResult."${action}"() 
					  println("INFO:: Resource $action successful. File: $fileName")
                      }else { 
					  def actionRes=tmpResult."${action}"(toDavUrl+'/'+fileName)
					      if (actionRes) { 
						     println("INFO:: Resource $action successful. File: $fileName. Status:"  + actionRes.exists())
							 actionRes.close()
                          }else {
						     println("WARNING:: Cannot perform resource action=$action as target resource already exists ::$fileName" )
						  }
						  
 						  
                      } 					  
			         }catch(DAVException ex) {
			          println("ERROR: DAV Exception Failed Resource action $action :" + ex.getMessage())
					  }catch(Exception ex) { 
					  println("ERROR: Generic Exception Failed Resource action $action :" + ex.getMessage())
			         }
			   
			   tmpResult.close()
			   }
			 }else{
			 println("WARNING:Action : $action :: No files found in fromDavUrl:"+fromDavUrl+" or nothing matched pattern:"+pattern)
			 }
			 
			 
		  }else if (res.SUCCEEDED() && (pattern == null || pattern=='')) {
		     try { 
		     if (action == 'delete' ) {  
		     res."${action}"()
			 println("INFO:: Resource $action successful")
			 }else { 
			 def actionRes=res."${action}"(toDavUrl)
			 if (actionRes) { 
				    println("INFO :: Resource $action successful. Status:"  + actionRes.exists())
					actionRes.close()
                }else {
					println("WARNING:: Cannot perform resource action=$action as target resource already exists ::$toDavUrl" )
				}  
			 }
			}catch(DAVException ex) {
			          println("ERROR: DAV Exception Failed Resource action $action :" + ex.getMessage())
			 }catch(Exception ex) { 
					  println("ERROR: Generic Exception Failed Resource action $action :" + ex.getMessage())
			 }		
		  }
         res.close()  
		 return null;
	 }
	 
	 

     /* searches files in directory and returns closure.  The resultant array of map will have keys : fileNameWithPath , fileName ,fileDirPath
      Function searches recursively 
      def array=[]
      getAllFiles(dirpath, pattern) {array << it }
      print
      */

     def getAllFiles(String dir,String fileToFind,Closure closure) {
          println "Directory for search is " + dir;
          println "FILE PATTERN TO FIND IS " + fileToFind;
          /* println FileSystems.getDefault();
           println FileSystems.getDefault().getSeparator();*/
          def sep=FileSystems.getDefault().getSeparator();
          def currentDir = new File(dir);
          def tempDir=dir.replaceAll("\\\\","@");
          /* println "TEMPDIR ESCAPED::" + tempDir;*/
          currentDir.eachFileRecurse(FileType.FILES){
               if( it.name=~/$fileToFind/) {
                    def tempMap=[:];
                    tempMap['fileNameWithPath']=it;
                    tempMap['fileName']=it.getName();
                    /* tempMap['libname']=it.getParentFile().getName();*/
                    tempMap['fileDirPath']=it.getParent();
                    def temp=it.getParent().replaceAll("\\\\","@");
                    /* tempMap['parentDirStruct']=temp.replaceAll(tempDir,'').replaceAll("^[@|/]",'').replaceAll('@','\\\\');*/
                    def match;
                    /* println "TEMP PARENT PATH IS ::" + temp;*/
                    if ((match = temp =~ /[\@|\/](\w+)[\@|\/](\w+)$/ )){
                         def rootDir=match.group(1);
                         def modelDir=match.group(2);
                         /* println temp+'::'+rootDir + '::' + modelDir;*/
                         /* tempMap['parent_root_dir']=rootDir;
                          tempMap['model_dir_name']=modelDir;*/
                    }


                    /*println tempMap.getAt('parent_root_dir')+'::::'+ temMap.getAt('model_dir_name')+':::'+ temMap.getAt('libname')+'::::'+tempMap.getAt('libpath');*/
                    closure.call(tempMap);
               }
          }
     }


     /*example 
      Tools.loadWorkflows(protocol,hostname,port,MetaUser,MetaPass,basePathContent+"/workflow_template/",basePath+"/log") 
      */

     void loadWorkflows(protocol,midtierHost,midtierPort,user,password,inputDir,outputTempDir,replace=false,activate=false) {
          System.setProperty('port',midtierPort)
          System.setProperty('host',midtierHost)
          System.setProperty('protocol',protocol)
          println("NOTE: loadWorkflows :: ${protocol}://${midtierHost}:${midtierPort} ")
          def loader = null;
          try
          {
               Class c = Class.forName("com.sas.workflow.util.checkin.WorkflowLoader")
               loader = c.newInstance()
               try {
                    loader.getWorkflowProxy().login(user, password)
                    loader.verifyWorkflowService()
                    def currentDir = new File(inputDir)
                    currentDir.eachFileRecurse(FileType.FILES) {
                         if(it.name.endsWith('.xml')) {
						      println("INFO::Processing :: "+ it.toString()) 
                              loader.checkin(it.toString(),outputTempDir,replace,activate)
                         }
                    }
               } catch(Exception e) {
                    e.printStackTrace()
               }
          }catch(Exception e){
               println(e.toString())

          }

     }


     def setAdminToolsEnv(wipDbPass=null,mrmDbPass=null,adminToolsPath) {
          println("############You are in setAdminToolsEnv #################")
          def dbScriptsDir=adminToolsPath+'/dbscripts/'
          def passFile=dbScriptsDir+'/pass.txt'
          def delStatus=new File(passFile).delete()
          println('NOTE:Deleted pass.txt file status::'+delStatus)
          def newlineChar=System.getProperty("line.separator")
          def dir=new File(dbScriptsDir)
          if (dir.exists()) {
               if ((wipDbPass != null &&  wipDbPass.trim() != '') && (mrmDbPass != null && mrmDbPass.trim() != '')){
                    println('NOTE:Creating pass.txt file')
                    def file=new FileWriter(passFile)
                    file.write(wipDbPass+newlineChar+mrmDbPass+newlineChar)
                    file.close()
                    System.setProperty('passFile','pass.txt')
               }
               System.setProperty('dbScriptsDir',dbScriptsDir)

               return 0
          } else {
               println('RGFERROR: Cannot Find Admin Tools on this machine')
               return -1
          }
     }


     def dataload(dataLoadInputDir=basePathContent+'/data_loader_files',sequenceFile=basePathContent+'/data_loader_files/data_load_sequence.txt',otherArgs='',resultDir=basePath+'/log/',dbScriptsDir=System.properties['dbScriptsDir'],passFile=System.properties['passFile']) {
          println("NOTE:dbScriptsDir: " + dbScriptsDir + "\n passFile: " + passFile + " \n dataLoadInputDir: " + dataLoadInputDir + "\n sequenceFile: " + sequenceFile)
          def command="addxlsdata.sh"
          if (System.properties['os.name'].toLowerCase().contains('windows')) {
               command="addxlsdata.cmd"
          }
          def file=new File(sequenceFile)
          if (file.exists()) {
               file.getText('UTF-8').eachLine {
                    line ->
                    if (line =~ /^\s*#/ || line =~ /^\s*$/ ){
                         println('Ignoring Commented File or Blank line :: '+ line)
                    }else {
                         println('#####Loader File to process::'+ line.trim()+' #####')
                         def commandToExecute=command+' '+dataLoadInputDir+'/'+line.trim()
                         def arr = new String[4]
                         arr[0] = dbScriptsDir+'/'+command
                         arr[1]=dataLoadInputDir+'/'+line.trim()
                         arr[2]='--resultsDir'
                         arr[3]=resultDir
                         if (! new File(arr[1]).exists()) {
                              println('ERROR:: Dataload CSV File Not Found:' +arr[1])
                              return 1
                         }
                         def extension=line.substring(line.lastIndexOf('.')+1)
                         println("Extension of file is " + extension)
                         if (extension.equalsIgnoreCase('csv')) {
                              println("Found CSV file " + arr[1])
                              File csvF = new File(arr[1]);
                              def fname=csvF.getName()
                              println('File Name is ' + fname)
                              def fnameWoExt=fname.substring(0,fname.lastIndexOf('.'))
                              def shtName=null
                              if ( fnameWoExt =~ /_/ ) {
                                   shtName=fname.substring(0,fname.lastIndexOf('_'))
                              }else {
                                   shtName=fnameWoExt
                              }
                              println('File Name is ' + fname  +  '::FileNameWithoutExt::' + fnameWoExt + '::LoaderName::'+shtName)
                              Path p1=Paths.get(resultDir)
                              Path tempDL=Files.createTempFile(p1, fnameWoExt+'dLoad', '.xlsx')
                              println('Dataload xlsx file is '+tempDL.toString())
                              csvToXLSX(arr[1],tempDL.toString(),shtName)
                              arr[1]=tempDL.toString()
                         }

                         def arrCmd=dbScriptsDir+'/'+command+' '+arr[1]+' '+'--resultsDir'+' '+resultDir
                         if (otherArgs != '') {
                              arrCmd=arrCmd+' '+otherArgs
                         }
                         arrCmd=arrCmd.replaceAll("\\s+"," ")
                         def newArr=arrCmd.split(' ')
                         println("Array of Command "+newArr)
                         def passTxtFile=new File(dbScriptsDir+'/pass.txt')
                         if (passTxtFile.exists()) {
                              runCmdLine(newArr,dbScriptsDir+'/',dbScriptsDir+'/pass.txt')
                         }else {
                              runCmdLine(newArr,dbScriptsDir+'/')
                         }
                    }
               }
          }else {
               println("ERROR: Cannot find sequence file:: "+ sequenceFile )
               return 1
          }
     }


     def runSyncUserRoles(syncType='users',otherArgs='',dbScriptsDir=System.properties['dbScriptsDir'],passFile=System.properties['passFile']) {

          def command
          if (syncType.equalsIgnoreCase('users')) {
               if (System.properties['os.name'].toLowerCase().contains('windows') ) {
                    command="syncusers.cmd"
               }else {
                    command="syncusers.sh"
               }
          }

          if (syncType.equalsIgnoreCase('roles')) {
               if (System.properties['os.name'].toLowerCase().contains('windows') ) {
                    command="syncroles.cmd"
               }else {
                    command="syncroles.sh"
               }
          }

          def arrCmd=dbScriptsDir+'/'+command
          if (otherArgs != '') {
               arrCmd=arrCmd+' '+otherArgs
          }
          arrCmd=arrCmd.replaceAll("\\s+"," ")
          def newArrCmd=arrCmd.split(' ')
          println("Array of Command:"+arrCmd)
          def passTxtFile=new File(dbScriptsDir+'/pass.txt')
          if (passTxtFile.exists()) {
               runCmdLine(newArrCmd,dbScriptsDir+'/',dbScriptsDir+'/pass.txt')
          }else {
               runCmdLine(newArrCmd,dbScriptsDir+'/')
          }

     }


     def runAdminToolsCmd(scriptName='',otherArgs='',dbScriptsDir=System.properties['dbScriptsDir'],passFile=System.properties['passFile']) {

          def command=''
          if (System.properties['os.name'].toLowerCase().contains('windows') ) {
               command=scriptName+'.cmd'
          }else {
               command=scriptName+'.sh'
          }

          def arrCmd=dbScriptsDir+'/'+command
          def file=new File(arrCmd)

          if (file.exists()) {
               if (otherArgs != '') {
                    arrCmd=arrCmd+' '+otherArgs
               }
               arrCmd=arrCmd.replaceAll("\\s+"," ")
               def newArrCmd=arrCmd.split(' ')
               println("Array of Command:"+arrCmd)
               def passTxtFile=new File(dbScriptsDir+'/pass.txt')
               if (passTxtFile.exists()) {
                    runCmdLine(newArrCmd,dbScriptsDir+'/',dbScriptsDir+'/pass.txt')
               }else {
                    runCmdLine(newArrCmd,dbScriptsDir+'/')
               }

          }else {
               println('ERROR: '+scriptName+' not found at '+dbScriptsDir+'.' )
          }

     }



     /* reads source and appends the target in the end. If the properties are found they are removed from source and then target content is appended
      Only works with files which have key and value separated by = 
      Files like configdata and custom messages.
      */
     def readandMergePropFiles(sourceFile,filetoPatch,outFile,replace=false) {
          //println("***Merging Starts***")
          println("NOTE:SourceFile::${sourceFile}")
          println("Note:FiletoMerge::${filetoPatch}")
          println("NOTE:OutFile::${outFile}")
          def srcFileCheck= new File(sourceFile)
          def filetoPatchCheck= new File(filetoPatch)

          if (! srcFileCheck.exists() || ! filetoPatchCheck.exists() )    {
               println("ERROR:Source File or File to Merge doesn't exist. sourceFile=${sourceFile}::filetoPatch=${filetoPatch}")
               return false
          }

          def configDataPropToAdd=[:]
          /*Holding file to merge content in a map */
          new File(filetoPatch).getText('UTF-8').eachLine {
               line ->
               def m
               if ((m = line =~ /^(.*)\=(.*$)/)) {
                    debug(m.group(1).trim()+"="+m.group(2).trim())
                    configDataPropToAdd.put(m.group(1).trim(),m.group(2).trim())
               }
          }

          /* opened outfile to write to it*/        
          //            def file=new FileWriter(outFile)
          FileOutputStream fileStream = new FileOutputStream(new File(outFile));
          OutputStreamWriter file = new OutputStreamWriter(fileStream, "UTF-8");

          /* iterating over each line of sounce file further check if the key exists in target then ignore writing to outfile. 
           This way all matching keys from sourceFile2 will be removed when we write final out file. 
           In the end we will simply append  */
          new File(sourceFile).getText('UTF-8').eachLine {
               line ->
               def found=0
               def m
               if ((m = line =~ /^(.*)\=(.*$)/)) {
                    if (configDataPropToAdd.containsKey(m.group(1).trim()) && replace==true) {
                         debug('Key already exists!!. Replace='+replace)
                         debug(m.group(1).trim()+"="+m.group(2).trim())
                         found=1
                    }

                    if (configDataPropToAdd.containsKey(m.group(1).trim()) && replace==false) {
                         debug('Key already exists!!. Replace='+replace)
                         debug(m.group(1).trim()+"="+m.group(2).trim())
                         found=0
                         configDataPropToAdd.remove(m.group(1).trim())
                         /* removing the key from map */
                    }
               }

               if (found) {
                    found=0
               }else {
                    file.write(line+'\n')
               }
          }

          if (replace==true)        {
               String filetoPatchContent = new File(filetoPatch).getText('UTF-8')
               file.write(filetoPatchContent)
          }else  {
               /* Keep only the keys which are in map rest needs to be removed from file.*/
               if (configDataPropToAdd.size() > 0) {
                    def temp = File.createTempFile('temp', '.txt')
                    def fileTemp=new FileWriter(temp)
                    new File(filetoPatch).getText('UTF-8').eachLine {
                         line ->

                         def m

                         if (line =~ /^ *\#/) {
                              debug('Found comment :: ' + line + 'writing to file')
                              fileTemp.write(line+'\n')
                         }else  {

                              if ((m = line =~ /^(.*)\=(.*$)/) ) {

                                   if (configDataPropToAdd.containsKey(m.group(1).trim())){
                                        fileTemp.write(line+'\n')
                                   }
                              }
                         }
                    }


                    debug("NOTE:Merged Temp file::"+ temp.absolutePath)
                    fileTemp.close()
                    String filetoPatchContent = new File(temp.absolutePath).getText('UTF-8')
                    file.write(filetoPatchContent)
               }
          }

          println("NOTE:Updated Content locally to :: ${outFile}")
          file.close()
          //println("***Merging Ends***")
          return true
     }


     def csvToXLSX(csvFile='CC',xlsxFile='CC',sheetNm=null) {
          try {

               File csvFileH = new File(csvFile)
               def fname=csvFileH.getName()
               def extension=csvFile.substring(csvFile.lastIndexOf('.')+1)
               def fnameWoExt=fname.substring(0,fname.lastIndexOf('.'))
               if (sheetNm == null ) {
                    sheetNm=fnameWoExt
               }
               println("INFO::CSV file Name is::" +  fname  + "::Name of sheet to be create is::"+ sheetNm);
               File xlsxFileH = new File(xlsxFile);
               XSSFWorkbook workBook = new XSSFWorkbook();
               XSSFSheet sheet = workBook.createSheet(sheetNm);
               int RowNum=0;
               BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(csvFileH), "UTF8"));
               def totalItems=0
               def currentLine=null
               while ( (currentLine = br.readLine())  != null) {
                    def arr=[]
                    /* split csv line */
                    def str = currentLine.split(",")
                    /* ncr is just used to find out empty lines*/
                    def ncr=currentLine.replaceAll("\\s+",'')
                    XSSFRow currentRow=sheet.createRow(RowNum);
                    if (ncr != '' ) {
                         def tmp=''
                         println('INFO::csvToXLSX::RowNum:' + RowNum + ' Row Length ' + str.length)
                         for(int i=0;i<str.length;i++){
                              /* println(i+'items:' + str[i] + 'temp :' + "'"+ tmp +"'")
                               def strTemp=str[i].trim()*/
                              def strTemp=str[i]
                              /*Condition searching if element in double quotes*/
                              if (strTemp  =~ /^"/ && tmp == '' && strTemp  =~ /\"$/) {
                                   tmp=strTemp
                                   println('INFO::csvToXLSX::RowNum:'+ RowNum + 'Cell :' +tmp)
                                   arr.add(tmp)
                                   tmp=''
                                   continue
                              }
                              /* if previous condition didn't match we look for this. We grab this value and loop again
                               "hello,world,rewrw" : Trying to match "hello        */
                              if (strTemp  =~ /^\"/ && tmp == '') {
                                   tmp=tmp+strTemp
                                   continue
                              }

                              /* Here we check tmp already some value but not ended with quotes . We can check whether new value of str starts with
                               quotes and tmp is not empty. This means split has multiple values  
                               "hello,world,rewrw" : Trying to match world */     
                              if (strTemp  =~ /^\"/ && tmp!= '') {
                                   tmp=tmp+','+strTemp
                                   continue
                              }

                              /* "hello,world,rewrw" : Trying to match world */     
                              if (tmp != '' && !(strTemp =~ /\"$/) && !(strTemp =~ /^\"/)){
                                   tmp=tmp+','+strTemp
                                   continue
                              }

                              /* "hello,world,rewrw" : Trying to match rewrw" */     
                              if (tmp != '' && (strTemp =~ /\"$/) ){
                                   tmp=tmp+','+strTemp
                                   arr.add(tmp)
                                   println('INFO::csvToXLSX::Rownum ::'+ RowNum + 'Cell :' +tmp)
                                   tmp=''
                                   continue
                              }else {
                                   tmp=strTemp
                                   arr.add(tmp)
                                   println('INFO::csvToXLSX::Rownum ::'+ RowNum + 'Cell :' +tmp)
                                   tmp=''
                                   continue
                              }

                         }

                    }


                    for(int i=0;i<arr.size();i++){
                         /* println(i+' ' +  arr.get(i))*/
                         def val=arr.get(i).replaceFirst(/^\"/,'')
                         val=val.replaceFirst(/\"$/,'')
                         currentRow.createCell(i).setCellValue(val)
                    }
                    RowNum++
               }

               FileOutputStream fileOutputStream =  new FileOutputStream(xlsxFileH);
               workBook.write(fileOutputStream)
               fileOutputStream.close()

               println("INFO::Done Creating XLSX" + xlsxFileH.getAbsolutePath() + '.Sheet Name::' + fnameWoExt)
          } catch (Exception ex) {
               println("ERROR::Exception in creating csv to xlsx :: " + ex.getMessage())
          }
     }


def runToolsCmd(scriptName,otherArgs,scriptsDir,stdinFile=null,regexExclude=null) {
        println("######RunToolsCmd Start :: ${scriptName}######")
          def command=''
          def dir = new File(scriptsDir)
        def (execFile,scriptsDirFinal)=findFile(scriptName,scriptsDir,regexExclude=regexExclude)
          if (execFile != null ) {
          def file=new File(execFile)
          
        if (file.exists()) {
               def arrCmd=execFile+' '+otherArgs 
               def (paddedStr,newArrCmd)=argParse(arrCmd)
               println("INFO:Array of Command:"+newArrCmd + '::'+newArrCmd.getClass())
               def inFile=new File(scriptsDir+'/stdinFile')
               if (inFile.exists()) {
                     return runCmdLine(newArrCmd,scriptsDirFinal+'/',scriptsDir+'/stdinFile')
               }else {
                    return runCmdLine(newArrCmd,scriptsDirFinal+'/')
               }

          }
          
          }else {
               println('ERROR:'+scriptName+' not found at '+scriptsDir+'.' )
          }

          
          
        
          
     }
     
     
def findFile(scriptName,scriptsDir,regexExclude=null) {
          println('INFO:Regex to Exclude ::'+regexExclude)
        def scriptsDirFinal=null
          def execFile=null
          def dir = new File(scriptsDir)
        dir.eachFileRecurse (FileType.FILES) {  
             if (it.name=~/$scriptName/ ) {
               
             if (it.name =~ /$regexExclude/) {
                         println ("INFO:Found it but not intrested :: $it") 
                    return
              }else {
                       println("INFO:Found it and intrested. Script Name::"+it.name + ". Base Dir:: " + it.getCanonicalFile().getParent())
                         /* not efficient but does the job. We need to actually break it here */
                         execFile=it.path
                         scriptsDirFinal=it.getCanonicalFile().getParent()
                }
             
                
             }
             
             
             }
            
            if (execFile == null ){
            println("ERROR: Cannot find ${execFile} at ${scriptsDir}")
            }else {
            return [execFile,scriptsDirFinal]
            }
}  
            
            

     
def runSAS(sasFile,args,serverContextName,MetaHost, Metaport , MetaUser, MetaPass, sasUser, sasPassword, Metarepository,logFile=null) {
         println("INFO:In function runSAS.")
          def sasFileName=new File(sasFile).getName()
          def getDir=sasFile.replaceAll(sasFileName,'')
          println("INFO: Directory of SAS Script "+getDir)
          def sasLogFile=logFile?:"$getDir/${sasFileName}.log"
          def sasCommand=System.getProperty("SASROOT")+'/sas'
          if (System.properties['os.name'].toLowerCase().contains('windows')) {
               sasCommand=System.getProperty("SASROOT")+File.separator+'sas.exe'
               sasCommand=sasCommand.replaceAll("\\\\","/")
          }
          
          println("INFO:SAS Executable ::" + sasCommand)
          if (new File(sasFile).exists() ) {
               def metaArgs="$sasCommand,-sysin,$sasFile,-metauser,$MetaUser,-metapass,$MetaPass,-metaserver,$MetaHost,-metaport,$Metaport,-metarepository,$Metarepository,-metaautoresources,$serverContextName,-log,$sasLogFile,-batch,-noterminal,-set,sasUser,$sasUser,-set,sasPassword,$sasPassword"
			   
  			   def (x,otherArgs)=argParse(args)
               List newArrCmd=metaArgs.replaceAll("\\s+"," ").split(',')
               newArrCmd.addAll(otherArgs)
               println("INFO:Run SAS with Args  :"+ newArrCmd)
			   
			   def sasExitCode=runCmdLine(newArrCmd,System.getProperty("SASROOT").replaceAll("\\\\","/"))
			   
               println("INFO:Run SAS for file $sasFile exited with code :"+ sasExitCode)
               println("INFO:Run SAS Log file is :" + sasLogFile)
          
                     if (sasExitCode > 1) {
                       println("ERROR: Run SAS exit code for $sasFile is ::"+ sasExitCode)
                     }
               def sasLogFh=new File(sasLogFile)
                    if (sasLogFh.exists()) {
                      println("####Printing SAS Log for Run SAS action : $sasLogFile####")
					  sasLogFh.eachLine{println(it) }
                      println("####End SAS log####")
                    }else {
                         println("ERROR: Log file not found : $sasLogFile")
                         
                    }
             
                
          
          }else {
          println("ERROR: File not Found: $sasFile")
          }
          
}
          

/*  
    parse agrs to return list . 
	**Multi spaces woulkd turn in to single space. This is mainly to create array for running commandline
    def a="-set A Avalue -set D 'D value one two three' -set multi \"with spaces\"";
    def (paddedStr,newArrCmd,newArrCmdQuotePreserved)=argParse(a)
    println(newArrCmdQuotePreserved)
​    You will 3 results : 3rd one will have all quotes preserved. 
    [-set, A, Avalue, -set, D, 'D value one two three', -set, multi, "with spaces"]
	second result will have double quotes removed cause they are there to just wrap argument.
	[-set, A, Avalue, -set, D, 'D value one two three', -set, multi, with spaces]
*/
	  
          
def argParse(arg,pad='<>') { 
   
   def firstQuote=0
   def str='';
   for (int i=0 ;i<arg.length();i++) {
       //println(dd[i]+','+firstQuote+','+i)
       if ( (arg[i] == '"' || arg[i] == "'") && !firstQuote) {
          firstQuote=1
          str=str+arg[i]
          continue
       }
       if (firstQuote && arg[i] == ' ') {
          str=str+pad
          continue
       }
       if ((arg[i] == '"' || arg[i] == "'") && firstQuote==1 ) {
          firstQuote=0
          str=str+arg[i]
          continue
        }
        str=str+arg[i]
}

println('INFO:Padded Arguments Resolved to::'+ str)
def arr=str.split(' +')

/* sending array without double quotes */
def arr2=[]
arr.each { arr2.add(it.replaceAll(pad,' ').replaceAll('"',''))}


/* sending array with quotes as is */
def arr3=[]
arr.each { arr3.add(it.replaceAll(pad,' '))}
return [str,arr2,arr3]
}

     


}
new ToolsInternal()

