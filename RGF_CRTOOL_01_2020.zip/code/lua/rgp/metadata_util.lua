local M={}
local rgpstr=require 'rgp.string_util'

--[[ 
The dataset  passed must have sheet name Metadata_Property_Updates and first row must have : 
SOFTWARE_COMPONENT_NAME,PROPERTY_NAME,VALUE
Other 2 columns you can add are : REPOSITORY,ATTRIBUTE_NAME
They default to 
REPOSITORY:'Foundation'
ATTRIBUTE_NAME:'DefaultValue'
]]--

function M.create_update_metadataprop_bak(dataset)

print('####Processing Metadata Properties##################')

local dsid = sas.open(dataset)
local repo
for row in sas.rows(dsid) do
if (row.repository == nil or row.repository == '') then 
row.repository='Foundation'
end
if (row.attribute_name == nil or row.attribute_name == '') then 
row.attribute_name='DefaultValue'
end
if string.match(row._,"#") then 
print('#SKIPPED#::',row.software_component_name, row.property_name,row.attribute_name,row.value,row.repository)
else 
print(row.software_component_name, row.property_name,row.attribute_name,row.value,row.repository)
sas.submit([[  
%create_update_metadata_property(Repository=@repository@,SoftwareCompName=@software_component_name@,PropertyName=@property_name@,
AttribName=@attribute_name@,AttribValue=@attribute_value@);
]],{software_component_name=row.software_component_name,property_name=row.property_name,attribute_name=row.attribute_name,attribute_value=row.value,repository=row.repository},nil,4)
end 
end
sas.close(dsid)

end 


function M.get_all_prop_of_softcom(software_component_name,dsname,comp_type)
local comp_type=comp_type or 'SoftwareComponent'
sas.print("%3z Searching Properties for "..comp_type)
sas.submit([[ 
proc sql;
drop table @dsname@;
quit;

option mprint; 
%let SoftwareCompName=@software_component_name@;

data @dsname@;
   length uri_software_component $256;
   length software_component_name $256;
   software_component_name="&SoftwareCompName.";
    uri_software_component='';
    /* software_component_found = metadata_getnobj("omsobj:SoftwareComponent?@Name contains '&SoftwareCompName.'",1, uri_software_component);*/
	software_component_found = metadata_getnobj("omsobj:@comp_type@?@Name contains '&SoftwareCompName.'",1, uri_software_component);
    put uri_software_component=;
    if software_component_found = 1 then do; 
     PropertySets_found = 0;    /*ApplicationActions Tree found*/
     property_rc=1;
	 property_count=0;
     PropertySets_rc = 1;
     PropertySets_count = 1;
     length uri_PropertySets $256;
	 length uri_SetProperties $256;
 	 length property_Name $256.;
	 length property_Name_uri $256.;
	 length property_Name_DefaultValue $256.;
     uri_PropertySets = '';
      PropertySets_rc = metadata_getnasn(uri_software_component, "PropertySets", PropertySets_count, uri_PropertySets);
	  output;
      do while (property_rc>0) ;
	  property_count=property_count+1;
      property_rc=metadata_getnasn(uri_PropertySets, "SetProperties", property_count,property_Name_uri );
		property_name_rc=metadata_getattr(property_Name_uri, "Name", property_Name);
		property_defVal_rc=metadata_getattr(property_Name_uri, "DefaultValue", property_Name_DefaultValue);
		/* put property_Name_uri=;
        put property_rc=;
  		put property_Name=; */
		if (property_rc >= 0 ) then do;
        output;
		end;
		
		
        end;
        end;
	  else do;
	  software_component_found=-99;
	  output;
	  end;
run;

]],{software_component_name=software_component_name,dsname=dsname,comp_type=comp_type},nil,4)


end


function M.create_update_metadataprop(dataset)
print('####Processing Metadata Properties####')
sas.submit([[  
option mprint;
proc sql;
create table softCOm as select distinct software_component_name as software_component_name from @dataset@;
quit;
]],{dataset=dataset},nil,4)
local sdsid = sas.open("work.softCOm")

--Loop start for all distinct software component
for srows in sas.rows(sdsid) do

--print(srows.software_component_name)
M.get_all_prop_of_softcom(srows.software_component_name,'all_prop')

sas.submit([[
option mprint;
proc sql;
create table _SoftComp as select * from @dataset@ where software_component_name in ("@softCom@");
quit;
data _SoftComp;
set _SoftComp;
attrib attribute_name format=$256. informat=$256.;
attrib repository format=$256. informat=$256.;
run;

proc sql;
create table _SoftCompDetail as select a.software_component_name ,a.property_name , a.value, a.attribute_name,a.repository,a.force, b.uri_propertysets,b.property_name as prop_name_from_sof_comp, 
b.property_name_uri,property_name_defaultvalue , property_name_rc
from _SoftComp as a LEFT join @all_prop@
		as b on a.software_component_name=@all_prop@.software_component_name and a.property_name=b.property_name  ;
		
quit;

]],{dataset=dataset,all_prop='all_prop',softCom=srows.software_component_name},nil,4)

print ("INFO: Started With::",srows.software_component_name)
local dsid = sas.open("work._SoftCompDetail")
for rows in sas.rows(dsid) do

if (rows.repository == nil or rows.repository == '') then 
rows.repository='Foundation'
end
if (rows.attribute_name == nil or rows.attribute_name == '') then 
rows.attribute_name='DefaultValue'
end


if (rows.property_name_uri ~= "" ) then 
if (rows.force ~= 0 ) then 

sas.print("%3z Updating Property ::"..rows.property_name)
sas.print("%3z Property Details ::"..table.tostring(rows) )
 sas.submit([[  
%let rc=99;
data _null_;
     length name $200
    	   desc $200
    	   modified $100;
    rc=metadata_setattr("@property_name_uri@","@attribute_name@","@value@");
    put rc=;
    
call symputx("rc",rc);

run;
]],{property_name_uri=rows.property_name_uri,value=rows.value,attribute_name=rows.attribute_name},nil,4)

local rc = sas.symget("rc") 
if ( rc == 0 ) then 
sas.print("%3z Metadata : Successfully Updated Property :".."Property Name :"..rows.property_name.." Software Component Name :"..rows.software_component_name)
else 
sas.print("%1z Metadata : Failed to Update Property :".."Property Name :"..rows.property_name.." Software Component Name :"..rows.software_component_name)
end 

else 
sas.print("%2z Metadata : No Updates made :".."Property Name :"..rows.property_name.." Software Component Name :"..rows.software_component_name)
end

end

if (rows.property_name_uri == "" or  rows.property_name_uri == nil) then 
print ("INFO:Creating Property ::",table.tostring(rows))

sas.submit([[
%let rc=99;
data a;
   length uri_software_component $256;
    uri_software_component='';
    software_component_found = metadata_getnobj("omsobj:SoftwareComponent?@Name contains '@software_component_name@'",1, uri_software_component);
    put uri_software_component=;
    if software_component_found = 1 then do;
     PropertySets_found = 0;    /*ApplicationActions Tree found*/
     property_rc=1;
     PropertySets_rc = 1;
     length uri_PropertySets $256;
     length property_Name_uri $256.;
     uri_PropertySets = '';
     PropertySets_rc = metadata_getnasn(uri_software_component, "PropertySets",1, uri_PropertySets);
     property_rc=metadata_newobj('Property', property_name_uri,"@property_name@","@repository@",uri_PropertySets,"SetProperties" );
     prop_name_rc=METADATA_SETATTR(property_name_uri, 'PropertyName', "@property_name@");
     prop_usage_ver_rc=METADATA_SETATTR(property_name_uri, 'UsageVersion', 0);
    prop_name_rc=METADATA_SETATTR(property_name_uri, "@attribute_name@", "@value@");
output;
put property_rc= prop_name_rc= prop_usage_ver_rc= ;
call symputx("rc",prop_name_rc);

end;
run;]],{software_component_name=rows.software_component_name,property_name=rows.property_name,value=rows.value,attribute_name=rows.attribute_name,repository=rows.repository},nil,4)

local rc = sas.symget("rc") 
if ( rc == 0 ) then 
print("INFO: Metadata : Property created Successfully :","Property Name :",rows.property_name,"Software Component Name :",rows.software_component_name)
else 
print("WARNING: Metadata : Failed to create Property :","Property Name :",rows.property_name,"Software Component Name :",rows.software_component_name)
end 



end


end
print ("INFO: Ended With::",srows.software_component_name)

sas.close(dsid)

end 
--Loop end for all distinct software component

sas.close(sdsid)



end 





function M.get_rest_end_point_dtls(AppRestCompName)
sas.submit([[
%get_rest_end_point_dtls(CompName=ServiceRegistry REST);
]],{CompName=AppRestCompName},nil,4)

end





--[[
Finds out all properties of software components and returns array of tables.
keys of each array table is  : property_name,property_name_uri,property_name_defaultvalue
--]]
function M.get_properties_from_soft_comp(SoftwareComponentName,whereClause)
sas.submit([[
%get_properties_from_soft_comp(Software_comp_name=@CompName@,outDataset=props,where_clause=@whereCls@);
]],{CompName=SoftwareComponentName,whereCls=whereClause})

local dsid = sas.open("work.props")
local arraytab={}
local i=1

for row in sas.rows(dsid) do
print(i,row.property_name,row.property_name_uri,row.property_name_defaultvalue)
arraytab[i]={["property_name"]=row.property_name , ["property_name_uri"]=row.property_name_uri ,["property_name_defaultvalue"]=row.property_name_defaultvalue }
i=i+1
end

sas.close(dsid)



return arraytab

end



function M.add_user_details(xlsFile,metarepository,login_sheet,midtierURL)

local misc=require 'rgp.misc_util' 

if (metarepository == nil )then
metarepository='Foundation'
end

sas.submit ([[
libname usr xlsx "@file@";

proc datasets library=usr;
   copy out=work;
run;

]],{file=xlsFile},nil,4)

if sas.exists("usr.New_Group_or_Role") then 
local dsid = sas.open("usr.New_Group_or_Role")
for row in sas.rows(dsid) do
--if string.match(row._,"#") then 
--print('#SKIPPED#::',row.software_component_name, row.property_name,row.attribute_name,row.value,row.repository)
--else 
print('New_Group_or_Role::'..table.tostring(row))

if (row.type == 'GROUP' ) then 
sas.submit([[  
%add_new_group(Group=@group@,GroupDesc=@groupDesc@,GroupDisplayName=@groupDisplayName@,Repository=@repository@);
]],{group=row.name,groupDesc=row.description,groupDisplayName=row.display_name,repository=metarepository},nil,4)
end 


if (row.type == 'ROLE' ) then 
sas.submit([[  
%add_new_role(Role=@group@,RoleDesc=@groupDesc@,RoleDisplayName=@groupDisplayName@,Repository=@repository@);
]],{group=row.name,groupDesc=row.description,groupDisplayName=row.display_name,repository=metarepository},nil,4)
end 


end 

sas.close(dsid)
end


if sas.exists("usr.Add_Role_to_Group") then 
local dsid = sas.open("usr.Add_Role_to_Group")
for row in sas.rows(dsid) do
--if string.match(row._,"#") then 
--print('#SKIPPED#::',row.software_component_name, row.property_name,row.attribute_name,row.value,row.repository)
--else 
--print('UserName::'..row.username,'UserDesc::'..row.userdesc,'UserTitle::'..row.usertitle,'UserDisplay::'..row.userdisplayname)
print('Add_Role_to_Group::'..table.tostring(row))
sas.submit([[  
%add_role_to_group(group=@group@,role=@role@,action=MODIFY);

]],{role=row.role_name,group=row.group_name,repository=metarepository},nil,4)
end 

sas.close(dsid)
end

if sas.exists("usr.Person") then 
local dsid = sas.open("usr.Person")
for row in sas.rows(dsid) do
--if string.match(row._,"#") then 
--print('#SKIPPED#::',row.software_component_name, row.property_name,row.attribute_name,row.value,row.repository)
--else 
--print('UserName::'..row.username,'UserDesc::'..row.userdesc,'UserTitle::'..row.usertitle,'UserDisplay::'..row.userdisplayname)
print('Person::'..table.tostring(row))
sas.submit([[  
%add_new_user(User=@username@,UserDesc=@userdesc@,UserDisplayName=@userdisplayname@ ,UserTitle=@usertitle@,Repository=@repository@);

]],{username=row.username,userdesc=row.userdesc,usertitle=row.usertitle,userdisplayname=row.userdisplayname,repository=metarepository},nil,4)
end 

sas.close(dsid)
end


if sas.exists("usr.group") then 
local dsid = sas.open("usr.group")
for row in sas.rows(dsid) do
--if string.match(row._,"#") then 
--print('#SKIPPED#::',row.software_component_name, row.property_name,row.attribute_name,row.value,row.repository)
--else 

print('Add Group or Role to User::'..table.tostring(row))
if (row.username ~= (nil or '') and row.group_or_role ~= (nil or '') ) then 
sas.submit([[  
%add_role_group_to_user(group=@group_or_role@,user=@username@,action=MODIFY);
]],{username=row.username,group_or_role=row.group_or_role,repository=metarepository},nil,4)

end

end 

sas.close(dsid)
end


if sas.exists("usr.email") then 
local dsid = sas.open("usr.email")
for row in sas.rows(dsid) do

print('Add email to User::'..table.tostring(row))
if (row.username ~= (nil or '') and row.emailtype ~= (nil or '')  and row.email ~= (nil or '') ) then 
sas.submit([[  
%add_email_to_user(email=@email@,user=@username@,EmailType=@emailtype@,Repository=@repository@);
]],{username=row.username,emailtype=row.emailtype,email=row.email,repository=metarepository},nil,4)

end

end 

sas.close(dsid)
end



if sas.exists("usr.phone") then 
local dsid = sas.open("usr.phone")
for row in sas.rows(dsid) do

print('Add Phone to User::'..table.tostring(row))
if (row.username ~= (nil or '') and row.phonetype ~= (nil or '')  and row.phone ~= (nil or '') ) then 
sas.submit([[  

%add_phone_to_user(phoneNumber=@phone@,user=@username@,PhoneType=@phonetype@,Repository=@repository@);
]],{username=row.username,phonetype=row.phonetype,phone=row.phone,repository=metarepository},nil,4)

end

end 

sas.close(dsid)
end


if sas.exists("usr."..login_sheet) then 
local dsid = sas.open("usr."..login_sheet)
for row in sas.rows(dsid) do
		

print('Add Login to User::'..table.tostring(row))
if (row.username ~= (nil or '') and row.login ~= (nil or '')  and row.authdomain ~= (nil or '') ) then 
sas.submit([[  

%add_login_details_to_user(User=@username@,Repository=@repository@,Login=@login@,
AuthenticationDomain=@authdomain@,Password=@password@);
]],{username=row.username,login=row.login,authdomain=row.authdomain,password=row.password,repository=metarepository},nil,4)

end

end 

sas.close(dsid)
end



if sas.exists("work.workflow_role") then 
local dsid = sas.open("usr.workflow_role")
print('Midtier URL ',midtierURL)
for row in sas.rows(dsid) do
print('Workflow Role::'..row.username.."::"..row.workflow_role)
  if (rgpstr.trim(row.username) ~= '' and rgpstr.trim(row.workflow_role) ~= '' ) then 
      M.workflow_role_set(midtierURL,row.username,row.workflow_role)
  else 
      sas.print("%2zworkflow_role_set:: skip row")
  end 

end
sas.close(dsid)
end


---Cleaning up datasets from work. Otherwise sample user task may pick up 
misc.dataset_delete("work","workflow_role phone email group New_Group_or_Role  Add_Role_to_Group Person InternalLogin "..login_sheet)

end





function M.add_role_capability(inputXLS,metahost,metaport,metarepository,metauser,metapassword,SoftwareComponentName,GroovyPath,tempDir)
--Handling case where we don't need to pass a directory for temp location.
tempDir=tempDir or nil
local fileExt=inputXLS:match("^.+%.(.+)$")
print(inputXLS..'Extension is ::'..fileExt)
if (fileExt ~= 'xls'  and   fileExt ~= 'xlsx' and fileExt ~= 'xml' and fileExt ~= 'appxml')  then 
local msg='ERROR:File is not xls(x) or xml or appxml'
print(msg)
--return {'rc'='99' , 'msg'=msg }
return 999
end

if (fileExt == 'xls'  or  fileExt == 'xlsx') then
sas.submit ([[
libname usr xlsx "@file@";
]],{file=inputXLS},nil,4)

if not sas.exists("usr.Role_X_Capability") then 
local msg='ERROR:Cannot find sheet role_x_capability'
print(msg)
--return {'rc'='99' , 'msg'=msg}
return 999
end

end



local groovy=[[
proc groovy; 
add PL="base/rgp.txt";
add sasjar="groovy";
add sasjar="Poi" ;
add sasjar="commons_collections4";
add sasjar="xmlbeans";
add sasjar="dom4j";
submit "&GroovyPath." "&inputXLS." "&metahost." "&metaport." "&metarepository." "&metauser" "&metapassword." "&softCompId." "&sashome_dir." "&sysver" "&fileExtension"  "&tempDir";
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFCell;
import java.nio.file.FileSystems;
import groovy.io.FileType;
import java.io.FileInputStream;
import groovy.xml.MarkupBuilder 

def (groovyPath,inputXLS,MetaHost,Metaport,Metarepository,MetaUser,MetaPass, softCompId,sashome_dir,sysver,fileExtension,tempDir)= args;
def xmlfile=null
if (tempDir == null || tempDir == '') { 
tempDir=null
}

if (fileExtension.equals('xml') || fileExtension.equals('appxml')) {
xmlfile=inputXLS
}else {
XSSFWorkbook wb = new XSSFWorkbook(new FileInputStream(inputXLS))
XSSFSheet sheet= wb.getSheet('Role_X_Capability')
println('Note:Role Cap Sheet:: '+sheet.toString())
File temp = File.createTempFile("temp",".xml",new File(tempDir))
PrintWriter pw=new PrintWriter(temp)
pw.println ("<ApplicationMetadata>");
def prevRole=null
for (def i = 1; i <= sheet.getLastRowNum(); i++) { 				 
def tempRow=sheet.getRow(i)
if (tempRow == null ) {
continue
} 
def cell0=tempRow.getCell(0).toString().trim()
def cell1=tempRow.getCell(1).toString().trim()

if (cell0.length() ==0 || tempRow.getCell(0) == null || tempRow.getCell(1) == null ||  tempRow.getCell(0) == '' || tempRow.getCell(1) == '') {
continue
}

if (!prevRole.equals(cell0)) {
if (i >  1) {
pw.println("</Capabilities>")
pw.println("</Role>")


}
pw.println("<Role Name="+ "'"+cell0+ "'"+">")
pw.println('<Capabilities> <Capability CapabilityId='+ "'"+cell1+"'/>")
prevRole=cell0
}else {
pw.println('<Capability CapabilityId='+ "'"+cell1+"'/>")
}

}

pw.println("</Capabilities>")
pw.println("</Role>")
pw.println ("</ApplicationMetadata>");
pw.close()
xmlfile=temp.getAbsolutePath()
}


def sashome_dir1=sashome_dir.replaceAll("\\\\","/")
def command_dir=sashome_dir1+"/SASPlatformObjectFramework/"+sysver+"/"
def command=command_dir+"/ApplicationMetadataUtility"
def arr = new String[8]
arr[0]='"'+command+'"'
arr[1]=' -host '+'"'+MetaHost+'" '
arr[2]=' -password '+'"'+MetaPass+'" '
arr[3]=' -port '+Metaport
arr[4]=' -user '+'"'+MetaUser+'" '
arr[5]=' -applicationId '+'"'+softCompId+'" '
arr[6]=' -localize '
arr[7]='"'+xmlfile+'"'

def tempExec
if (System.properties['os.name'].toLowerCase().contains('windows')) {
tempExec = File.createTempFile("role_cap_",".cmd",new File(tempDir));
}else {
tempExec = File.createTempFile("role_cap_",".sh",new File(tempDir));
def filePath=tempExec.getAbsolutePath()
"chmod +x ${filePath}".execute()
}

tempExec.write(arr.join(' '))
ProcessBuilder pb=new ProcessBuilder()
pb.redirectErrorStream(true);

pb.command(tempExec.getAbsolutePath())
println("Submitted Command ::"+  pb.command() )
println("Working Directory  ::"+  pb.directory() )
Process process=pb.start()
BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()))
			def s
			while ((s = stdInput.readLine()) != null) {
				println(s);
			}
process.waitFor()
println("Loading Roles and Capability :: Exit code ::"+ process.exitValue() )
]]


--Creating temp file which proc groovy. 
local endStmts=[[
endsubmit;
clear;
quit;
]]
local tmpfile=M.createTempFile(groovy,endStmts)

sas.submit([[
%let SoftwareComponentName=@SoftwareComponentName@;
%let softCompId=xx;
data _null_;
    length value $200;
    rc=metadata_getattr("omsobj:SoftwareComponent?@Name='"||"&SoftwareComponentName"||"'","id",value);
	put rc=;
    if rc=0 then put value= ;
	call symputx('softCompId',value);
run;
%let sashome_dir = %sysget(SASHOME);
%let GroovyPath = @GroovyPath@;
%let inputXLS=@inputXLS@;
%let metahost=@metahost@;
%let metaport=@metaport@;
%let metarepository=@metarepository@;
%let metauser=@metauser@;
%let metapassword=@metapassword@;
%let fileExtension=@fileExt@;
%let tempDir=@tempDir@;
%put NOTE: Software Component ID : &softCompId;
%put NOTE::Role capability Groovy ::@tmpfile@;
/* submitting proc groovy file*/
%include "@tmpfile@";

]],{GroovyPath=GroovyPath,inputXLS=inputXLS,metahost=metahost,metaport=metaport,metarepository=metarepository,metauser=metauser,metapassword=metapassword,
SoftwareComponentName=SoftwareComponentName,tmpfile=tmpfile,fileExt=fileExt,tempDir=tempDir},nil,4)



end 



function M.add_internal_users(inputXLS,metahost,metaport,metarepository,metauser,metapassword,GroovyPath)
sas.submit ([[
libname usr xlsx "@file@";
]],{file=inputXLS},nil,4)
if sas.exists("usr.internallogin") then 
local dsid = sas.open("usr.internallogin")
for row in sas.rows(dsid) do
print('Adding Internal Login::'..table.tostring(row))
if (row.username ~= (nil or '') and row.internallogin ~= (nil or '')  and row.password ~= (nil or '') ) then 
sas.submit([[  
%add_internal_user(MetaHost=@metahost@,Metaport=@metaport@,
Metarepository=@metarepository@,metauser=@metauser@,MetaPass=@metapassword@,NewInternalUserName=@internallogin@,
NewuserPassword=@password@,
Role=,GroovyPath=@GroovyPath@/internal_user_groovy.sas);
]],{GroovyPath=GroovyPath,username=row.username,internallogin=row.internallogin,password=row.password,metahost=metahost,metaport=metaport,metarepository=metarepository,metauser=metauser,metapassword=metapassword},nil,4)
end
end 
sas.close(dsid)
end

end 


function M.createTempFile(multiLineStringCode,appendStatements)

sas.submit([[
filename file TEMP;
%let filePath = %sysfunc(pathname(file));
]],{},nil,4)

local tmpFile=sas.symget("filePath")
print("tmpFile:: "..tmpFile)
local fileref =  sasxx.new("file")
local f = fileref:open("w")
--f:write("proc groovy ; \n submit; \n")
f:write(multiLineStringCode)
--f:write("endsubmit; \n quit; \n")
f:write(appendStatements..'\n')
f:close()

return tmpFile


end 

function M.get_prop_of_softcom(software_component_name,propname)
sas.submit([[ 
option nomprint; 
%let SoftwareCompName=@software_component_name@;
%let prop=@propname@;
data _null_;
    length val $1000;
    softwareComp="&SoftwareCompName.";
    prop="&prop.";
    val="";
    val = metadata_appprop(softwareComp,prop);
    sysrc=sysrc();
    sysmsg=sysmsg();
    put sysrc=;
    put sysmsg=;
    put val=;
	call symputx("value",val);
	call symputx("return_cd",sysrc);
run;


]],{software_component_name=software_component_name,propname=propname},nil,4)

local val=sas.symget("value")
local rc=sas.symget("return_cd")
return val,rc 


end




function M.get_uri_of_softcom(software_component_name)
sas.submit([[ 
option nomprint; 
%let SoftwareCompName=@software_component_name@;
data _null_;
    length protocol $20 hostname $80 port $20 service $100 url $400;
    rc = metadata_geturi("&SoftwareCompName.", url, protocol, hostname, 
port, service);
    put rc=;
    put url=;
    put protocol=;
    put hostname=;
    put port=;
    put service=;

	call symputx("rc",rc);
	call symputx("url",url);
	call symputx("protocol",protocol);
	call symputx("hostname",hostname);
	call symputx("port",port);
	call symputx("service",service);
 run;

]],{software_component_name=software_component_name},nil,4)

local rc=sas.symget("rc")
local url=sas.symget("url")
local protocol=sas.symget("protocol")
local hostname=sas.symget("hostname")
local port=sas.symget("port")
local service=sas.symget("service")



return protocol,hostname,port,url,service,rc


end



function M.run_amu(amu_file,metahost,metaport,metarepository,metauser,metapassword,SoftwareComponentName,tempDir)
--Handling case where we don't need to pass a directory for temp location.
tempDir=tempDir or nil
local fileExt=amu_file:match("^.+%.(.+)$")
sas.print("%2z"..amu_file..'::Extension is ::'..fileExt)
if (fileExt ~= 'xml' and fileExt ~= 'appxml')  then 
sas.print("%1z ::Only xml or appxml allowed")
print(msg)
return 999
end

local groovy=[[
proc groovy; 
add sasjar="groovy";
add sasjar="Poi" ;
add sasjar="xmlbeans";
add sasjar="dom4j";
submit "&amu_file." "&metahost." "&metaport." "&metarepository." "&metauser" "&metapassword." "&softCompId." "&sashome_dir." "&sysver" "&tempDir." ;
import java.nio.file.FileSystems;
import groovy.io.FileType;
import java.io.FileInputStream;

def (amu_file,MetaHost,Metaport,Metarepository,MetaUser,MetaPass, softCompId,sashome_dir,sysver,tempDir)= args;
def xmlfile=amu_file
def sashome_dir1=sashome_dir.replaceAll("\\\\","/")
def command_dir=sashome_dir1+"/SASPlatformObjectFramework/"+sysver+"/"
def command=command_dir+"/ApplicationMetadataUtility"

if (tempDir == null || tempDir == '') { 
tempDir=null
}


def arr = new String[8]
arr[0]='"'+command+'"'
arr[1]=' -host '+'"'+MetaHost+'" '
arr[2]=' -password '+'"'+MetaPass+'" '
arr[3]=' -port '+Metaport
arr[4]=' -user '+'"'+MetaUser+'" '
arr[5]=' -applicationId '+'"'+softCompId+'" '
arr[6]=' -localize '
arr[7]='"'+xmlfile+'"'

def tempExec
if (System.properties['os.name'].toLowerCase().contains('windows')) {
tempExec = File.createTempFile("run_amu_",".cmd",new File(tempDir));
}else {
tempExec = File.createTempFile("run_amu_",".sh",new File(tempDir));
def filePath=tempExec.getAbsolutePath()
"chmod +x ${filePath}".execute()
}

tempExec.write(arr.join(' '))
ProcessBuilder pb=new ProcessBuilder()
pb.redirectErrorStream(true);

pb.command(tempExec.getAbsolutePath())
println("Submitted Command ::"+  pb.command() )
println("Working Directory  ::"+  pb.directory() )
Process process=pb.start()
BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()))
			def s
			while ((s = stdInput.readLine()) != null) {
				println(s);
			}
process.waitFor()
println("ApplicationMetadataUtility :: Exit code ::"+ process.exitValue() )
]]


--Creating temp file which proc groovy. 
local endStmts=[[
endsubmit;
clear;
quit;
]]
local tmpfile=M.createTempFile(groovy,endStmts)

sas.submit([[
%let SoftwareComponentName=@SoftwareComponentName@;
%let softCompId=xx;
data _null_;
    length value $200;
    rc=metadata_getattr("omsobj:SoftwareComponent?@Name='"||"&SoftwareComponentName"||"'","id",value);
	put rc=;
    if rc=0 then put value= ;
	call symputx('softCompId',value);
run;
%let sashome_dir = %sysget(SASHOME);
%let amu_file=@amu_file@;
%let metahost=@metahost@;
%let metaport=@metaport@;
%let metarepository=@metarepository@;
%let metauser=@metauser@;
%let metapassword=@metapassword@;
%let fileExtension=@fileExt@;
%let tempDir=@tempDir@;
%put NOTE: Software Component ID : &softCompId;
%put NOTE::AMU Groovy ::@tmpfile@;
/* submitting proc groovy file*/
%include "@tmpfile@";

]],{amu_file=amu_file,metahost=metahost,metaport=metaport,metarepository=metarepository,metauser=metauser,metapassword=metapassword,
SoftwareComponentName=SoftwareComponentName,tmpfile=tmpfile,tempDir=tempDir},nil,4)



end 


--metadata_to_physical_ds("\\Products\\SAS Risk and Finance Workbench\\Process Dashboard\\Data\\Config","RFW_CONFIG") 
function M.metadata_to_physical_ds(meta_loc,dsname,create,force)

if (create == nil or create == '') then 
create=true
end

if (force == nil or force == '') then 
force=false
end
sas.submit([[ 
%mdsecds(FOLDER="@meta_loc@");
proc sql;
create table cols as select * from Mdsecds_objs where Location like ('%@dsname@%');
create table tab as select distinct * from Mdsecds_objs where MetadataType='PhysicalTable' and ObjName = '@dsname@';
quit;
data cols;
set cols;
attrib column_type format=$1024.  informat=$1024.;
attrib column_length format=$1024.  informat=$1024.;
attrib column_format format=$1024.  informat=$1024.;
attrib column_informat format=$1024.  informat=$1024.;
rc_col=METADATA_GETATTR(objUri, 'SASColumnLength', column_length);
rc_type=METADATA_GETATTR(objUri, 'SASColumnType', column_type);
rc_form=METADATA_GETATTR(objUri, 'SASFormat', column_format);
rc_inform=METADATA_GETATTR(objUri, 'SASInFormat', column_informat);
run;


data tab;
attrib taburi format=$1024.  informat=$1024.;
attrib libref format=$1024.  informat=$1024.;
set tab;
rc=METADATA_GETNASN(objUri, 'TablePackage' , 1, taburi);
rc1=METADATA_GETATTR(taburi, 'Libref', libref);
run; 

]],{meta_loc=meta_loc,dsname=dsname},nil,4)


local ds = sas.open("work.tab")
local tabrow=nil
for row in sas.rows(ds) do
tabrow=row
end
sas.print("%3z Libref "..tabrow.libref)
sas.close(ds)

sas.submit([[
libname @libref@ meta liburi="SASLibrary?@libref='@libref@'" METAOUT='DATA' ;
]],{libref=tabrow.libref},nil,4)

if (sas.exists(tabrow.libref..'.'..dsname) and force == false ) then  
sas.print("%2z Table already exists ::Libref::"..tabrow.libref.." Table Name::"..dsname)
else 

--Loop start for all distinct software component
local str=''
local sdsid = sas.open("work.cols")
for srows in sas.rows(sdsid) do
local tempStr=' '
tempStr=tempStr..srows.objname..' ' 

if (srows.column_type == 'C') then 
tempStr=tempStr..' char('..srows.column_length..') ' 
elseif (srows.column_type == 'N') then 
tempStr=tempStr..' num ' 
else 
sas.print("%1z :: This column_type not handled :: "..srows.column_type)
end

if (srows.column_format ~= "") then 
tempStr=tempStr..' format='..srows.column_format 
end

if (srows.column_informat ~= "") then 
tempStr=tempStr..' informat='..srows.column_informat 
end


if (srows.desc ~= "") then
tempStr=tempStr..' label='..'"'..srows.desc..'"'
end

tempStr=tempStr..','
str=str..tempStr
--print(srows.objname,srows.desc,srows.column_type,srows.column_length,srows.column_format,srows.column_informat)


end
str=string.gsub(str, ",$", "")
sas.close(sdsid)

local sql="proc sql; \n create table "..tabrow.libref..'.'..dsname.."\n("..str..");\n quit;"
sas.print("%2z SQL generated \n"..sql)

if (create == true) then 
sas.submit([[
@sql@
]],{sql=sql},nil,4)

--Check for dataset after it is created. 
if (sas.exists(tabrow.libref..'.'..dsname)) then  
sas.print("%2z Table Successfully created::Libref::"..tabrow.libref.." Table Name::"..dsname)
end

--Create end here
end 

--else ends here
end 

--Function Ends here.
end 


--Assumes there is one module available envluamap which has map and get function.
--input dataset : dataset 
--envluamap : value of module to load which has function config.get .
--resolved_dsname
function M.resolve_dataset(dataset,envluamap,resolved_dsname) 

sas.submit([[  
option mprint;
proc sql;
create table _softcom as select * from @dataset@;
/* create table __softcom as select * from @dataset@;
delete from __softcom; */
quit;
]],{dataset=dataset},nil,4)

local sdsid = sas.open("work._softcom")
--local dsid = sas.open("work.__softcom", "u")

local tab={}
--Loop start for all distinct software component
for srows in sas.rows(sdsid) do
print(srows.software_component_name,srows.property_name,srows.value,srows.attribute_name,srows.repository,srows.resolve,srows.force)
local tabtemp={}
tabtemp['resolve']=srows.resolve
tabtemp['software_component_name']=srows.software_component_name

if srows.resolve ~= nil and  srows.resolve==1 then 
tabtemp['property_name']=load("local config = require '"..envluamap.."'; return "..srows.property_name:gsub('+','..'))() 
tabtemp['value']=load("local config = require '"..envluamap.."'; return "..srows.value:gsub('+','..'))() 
else 
tabtemp['property_name']=srows.property_name
tabtemp['value']=srows.value
end

tabtemp['attribute_name']=srows.attribute_name
tabtemp['repository']=srows.repository
tabtemp['force']=srows.force or 1
tab[#tab+1]=tabtemp
--sas.append(dsid)
--sas.put(dsid, 'software_component_name', "srows.software_component_name")
--sas.put(dsid, "property_name", srows.property_name)
--sas.put(dsid, "value", srows.value)
--sas.put(dsid, "attribute_name", srows.attribute_name)
--if srows.repository ~= nil  then
--sas.put(dsid, "repository", srows.repository)
--end
--sas.update(dsid)
end
print("INFO: Resolved Lua table "..table.tostring(tab))
sas.write_ds(tab, resolved_dsname)
--print(type(sas.rows(sdsid)))
sas.close(sdsid)
--sas.close(dsid)

if sas.exists(resolved_dsname) then
print("INFO: Returning Resolved Dataset.")
return  resolved_dsname
else 
print("ERROR: Failed to find resolved dataset ")
return  nil
end

  
end



function M.metadata_get_midtier_details(ServiceComponentName ,type)
local ServiceComponentName=ServiceComponentName or 'LogonTicketService REST'
local type=type or 'REST'

sas.submit([[

%global service_endpoint;
%global service_registry_endpoint;
%svcreg(type=@type@, name=@service_name@);
%put endpoint=&service_endpoint.;
data svc;
str="&service_endpoint.";
parse=prxparse("/https?\:\/\/(.*)\:/");
app_context=prxparse("/(https?)\:\/\/(.*)\:(\d+)\/(.*?)\//");
if prxmatch(app_context, str) then do;  
protocol = prxposn(app_context, 1, str);
hostname = prxposn(app_context, 2, str);
port = prxposn(app_context, 3, str);
appName = prxposn(app_context, 4, str);
CALL SYMPUTX('hostname', hostname );
CALL SYMPUTX('port', port );
CALL SYMPUTX('protocol', protocol );
CALL SYMPUTX('appName', appName);
end;
run;

%put hostname=&hostname.;
%put port=&port.;
%put protocol=&protocol.;
%put appName=&appName.;

]],{service_name=ServiceComponentName,type=type},nil,4)
local tab={}
tab['midtierhost']=sas.symget('hostname')
tab['port']=sas.symget('port')
tab['protocol']=sas.symget('protocol')

local tab2={}
tab2[1]= { name='MIDTIERHOST'  , value=tab['midtierhost'] }
tab2[2]= { name='MIDTIERPORT'  , value=tab['port'] }
tab2[3]= { name='PROTOCOL'  , value=tab['protocol'] }

return tab,tab2

end

function M.workflow_role_set(url,user_id,role_name) 
 --Possible roles : ROLE_WORKFLOW_ADMINISTRATOR.ROLE_WORKFLOW_VIEWER, ROLE_WORKFLOW_EDITOR
 local func_name=debug.getinfo(1, "n").name 
 if (M.workflow_role_get(url,user_id,role_name)  ~= 0 ) then
     sas.print("%3z"..func_name..":Role:"..role_name.." already set for user::"..user_id.." .")
	 --Return 0 meaning role already exist so no need to set. 
	 return 0,'INFO:No need to add Role'
 end
  sas.submit([[
   filename in TEMP;
   filename resp TEMP;
   filename hout TEMP;
   data _null_;
   file in;
   input;
   put _infile_;
   datalines4;
<authorities>
    <role name="@role_name@"/>
</authorities>
;;;;
run;

proc http in=in HTTP_TOKENAUTH url="@url@/SASWIPClientAccess/rest/users/@user_id@/authorities"
      method="post"
	  out=resp
      ct="application/xml"
      headerout=hout
      ;
run;

%put &=SYS_PROCHTTP_STATUS_CODE;
%put &=SYS_PROCHTTP_STATUS_PHRASE;
]],{url=url,user_id=user_id,role_name=role_name},nil,4)

local status_code=sas.symget("SYS_PROCHTTP_STATUS_CODE")
local status_phrase=sas.symget("SYS_PROCHTTP_STATUS_PHRASE")
print('INFO::',status_code,status_phrase)

if status_code ~= 201 then 
	sas.print("%1z"..func_name..":Failed to add workflow role ::"..role_name.." for user "..user_id.." ." )
else
    sas.print("%3z"..func_name..":Role:"..role_name.." now set for user::"..user_id.." .")
end 

return status_code,status_phrase

end 


function M.workflow_role_get(url,user_id,role_name)
local func_name=debug.getinfo(1, "n").name 
local rolesReturnCd=0
local content=''
sas.submit([[
  
   filename resp TEMP;
   filename hout TEMP;

   proc http  HTTP_TOKENAUTH url="@url@/SASWIPClientAccess/rest/users/@user_id@/authorities"
      method="get"
	  out=resp
	  headerout=hout
      ;
   run;

  %put &=SYS_PROCHTTP_STATUS_CODE;
  %put &=SYS_PROCHTTP_STATUS_PHRASE;
  %let xmlPath=%sysfunc(pathname(resp));
  %put &=xmlPath;

/* data _null_;
   infile resp;
   input;
   put _infile_;
run; */
  
]],{url=url,user_id=user_id,role_name=role_name},nil,4)

local xmlPath=sas.symget('xmlPath')
print('xmlPath',xmlPath)
local f=io.open(xmlPath,'r')

if (f ~= nil) then
   content=f:read("*a")
   f:close()
   --sas.print(content)
   rolesReturnCd=content:find(role_name) or 0
end

local status_code=sas.symget("SYS_PROCHTTP_STATUS_CODE")
local status_phrase=sas.symget("SYS_PROCHTTP_STATUS_PHRASE")
--print(status_code,status_phrase)

if status_code ~= 200 then 
	sas.print("%1z "..func_name.."::Failed to get roles.")
	sas.print(content)
	return -1,content
end 


if (rolesReturnCd == 0) then 
  sas.print('%2zWorkflow Role not found::'..role_name..". Return Code::"..rolesReturnCd)
  return rolesReturnCd , content , status_code,status_phrase
else 

  sas.print('%3zWorkflow Role found::'..role_name..". Return Code::"..rolesReturnCd)
  return rolesReturnCd , content, status_code,status_phrase

end  



  
end




return M
