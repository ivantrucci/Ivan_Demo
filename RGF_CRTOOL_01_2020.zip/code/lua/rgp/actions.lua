
local meta=require 'rgp.metadata_util'
local json=require 'rgp.json'
local rgpstr=require 'rgp.string_util'
local rgpmisc=require 'rgp.misc_util'


local M={}
----Defining functions for actions 


--This functions load properties in file env.properties passed as
function M.load_properties_action(row,envPropFile,baseLogDirPath) 


if (row.attributes ~= nil and rgpstr.trim(row.attributes) ~= "") then 
local tab=json:decode(row.attributes)
print(row.attributes)

if (tab['softwareComponentName'] ~= nil and tab['softwareComponentName'] ~= "" and tab['prefix'] ~= nil and tab['prefix'] ~= "" ) then 
sas.print("%3z Loading properties from SoftwareComponent ::"..tab['softwareComponentName'])
meta.get_all_prop_of_softcom(tab['softwareComponentName'],tab['prefix'],tab['type'])
sas.submit([[
libname __tmp "@libPath@";
data __tmp.@dsname@(where=(property_name<>''));
set @dsname@;
run;

]],{dsname=tab['prefix'],libPath=baseLogDirPath},nil,4)

  outfile = io.open(envPropFile, 'ab')
  if (outfile ~= nil) then 
         outfile:write("##Properties of Software Component ::"..tab['softwareComponentName']..'## \n')
		 local ds=sas.open('__tmp.'..tab['prefix'])
		 for row in sas.rows(ds) do
		 outfile:write(tab['prefix']..'.'..row.property_name.."="..row.property_name_defaultvalue:gsub('\\','\\\\')..'\n')
         end
         outfile:close()
		 sas.close(ds) 
		
  end 
  
end

if ( tab['file'] ~= nil ) then
sas.print("%3z Loading properties from file ::"..tab['file'])
local file=nil
if (tab['resolve']) then 
sas.print("%3z Resolving File path::"..tab['file'])
--In future we may to use metaoperator & metatables.
file=load("local config = require 'envluamap' ; return "..tab['file']:gsub('+','..'))()
sas.print("%3z File path resolved to::"..file)
else 
sas.print("%3z File to load properties are ::"..sasConfLevPath..'/'..tab['file'])
file=sasConfLevPath..'/'..tab['file']
end
rgpmisc.file_copy(file,envPropFile,'ab','##Properties added from file :::'..file..'## \n')
end

if ((tab['softwareComponentName'] ~= nil and tab['softwareComponentName'] ~= "" and (tab['prefix'] == nil or  tab['prefix'] == ""))  or (tab['prefix'] ~= nil and tab['prefix'] ~= "" and (tab['softwareComponentName'] == nil or  tab['softwareComponentName'] == "")) ) then
sas.print("%1z ACTION ::"..row.task.."::Please ensure that ['softwareComponentName' and 'prefix'] is provided in task action.")
end

if ( tab['items'] ~= nil ) then
rgpmisc.write_key_value_to_file(tab['items'],envPropFile,'##Properties from'..json:encode(tab['items'])..'\n')
end

if ( tab['sasFile'] ~= nil ) then
print('INFO:: RUNNING SAS FILE FOR PROPERTIES.')
local finalSASFile=nil
if (tab['resolve']) then 
sas.print("%3z Resolving File path::"..tab['sasFile'])
--In future we may to use metaoperator & metatables.
finalSASFile=load("local config = require 'envluamap' ; return "..tab['sasFile']:gsub('+','..'))()
else 
finalSASFile=basePathContent..'/'..tab['sasFile']
end 

if io.open(finalSASFile) ~= nil then 
sas.submit([[
%let envPropFile=@envPropFile@;
%put envPropFile=&envPropFile;
%include "@finalSASFile@";
run;
]],{finalSASFile=finalSASFile,envFile=envPropFile},nil,4)

else 
sas.print("%1z LOAD_PROPERTIES:: Following sasFile not found :: "..tab['sasFile'])
end

end
end --for attributes
 
end --function load_properties_action end

----End of fucntions for actions 




return M