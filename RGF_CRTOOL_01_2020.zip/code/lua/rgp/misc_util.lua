local M={}
function M.file_copy(sourceFile,destinationFile,writeMode,fileMarker)
writeMode=writeMode or 'wb'

local  infile = io.open(sourceFile, "rb")
if (infile ~= nil) then
  instr = infile:read("*a")
  infile:close()
  outfile = io.open(destinationFile, writeMode)
  if (outfile ~= nil) then 
       if (fileMarker ~= nil ) then 
	     outfile:write(fileMarker)
	   end
      outfile:write(instr)
      outfile:close()
      sas.print("%3z Copy Success "..sourceFile.." to "..destinationFile)
	  return 0
  else 
      sas.print("%1z Cannot copy "..sourceFile.." to "..destinationFile..". Not able to Open"..destinationFile.." for writing.")
  end
 
else 
  sas.print("%1zCannot Find Source File :: "..sourceFile)
  return 1
end

end

function M.smd2ds(dirPath,baseName,libName)
local baseNameCopy=baseName
baseName=baseName..'_'
sas.submit([[
filename dirPath "@dirPath@";
]],{dirPath=dirPath},nil,4)
local localeStr=''
print("dirPath::",dirPath)
local logical = sasxx.new('dirPath')
local exists = logical:exists()
if (exists) then
    dir = logical:opendir()
    for dirent in dir:read() do
     --print(table.tostring(dirent))  
     local ind=string.find(dirent['name'],baseName)

    if dirent['name'] ~= '.' and dirent['name'] ~= '..' and ind then 
      local str=string.gsub(string.gsub(dirent['name'],baseName,''),'.smd','')
      print('SMD File::', dirent['name'],"Index :: ",ind, "Locale::", str)
	  localeStr=str..' '..localeStr

    end 

    end 

--Trimming spaces
localeStr=localeStr:gsub("%s+$",'')
print("All Locales ::".."'"..localeStr.."'")
if localeStr == ''  then 
sas.submit([[
%SMD2DS(DIR=@dirpath@, BASENAME=@basename@, lib = @libname@) ;
]],{dirpath=dirPath,basename=baseNameCopy,libname=libName},nil,4)
 else 
sas.submit([[
%SMD2DS(DIR=@dirPath@, BASENAME=@baseName@, locale=@localestr@, lib = @libName@) ;
]],{dirPath=dirPath,baseName=baseNameCopy,libName=libName,localestr=localeStr},nil,4)

end 

		 
else 
sas.print("%1zCannot Find Director::"..dirPath)
end 		 


end 

function M.file_exists(name)
   local f=io.open(name,"r")
   if f~=nil then io.close(f) return true else return false end
end



function M.write_key_value_to_file(map,file,comment,keyVar,valueVar,mode)
keyVar=keyVar or 'name'
valueVar=valueVar or 'value'
mode=mode or 'ab'
if (map ~= nil  ) then
outfile = io.open(file, mode)
  if (outfile ~= nil) then 
     if (comment ~= nil) then
        outfile:write(comment)
     end 
   for k,v in pairs(map) do
        --local k1=load('return v.'..keyx )() 
		local prefix=v[prefix] or ''
        print('INFO:: '..prefix..v[keyVar]..'='..v[valueVar]) 
		outfile:write(prefix..v[keyVar]..'='..v[valueVar]..'\n')
   end	
  outfile:close()
end 
end
  
end




function M.load_properties(inputFile,outFilePath,moduleName) 
local startBlock=[[
local M={}
M.tab={
]]

local endBlock=[[
function M.get(key)
--print('In mget',key,M.tab['x'])
return M.tab[key]
end
return M

]]

local outfile = io.open(outFilePath..'/'..moduleName..'.lua', 'w')

if (outfile ~= nil ) then 
outfile:write(startBlock..'\n')

 for line in io.lines(inputFile) do 
   if (string.match(line, '^%s*#')) then 
     outfile:write('--'..line..'\n' )    
   else 
      line=string.gsub(line , "=%s*", "=")
      for k, v in string.gmatch(line, "(.+)=(.+)") do

      outfile:write("['"..k.."']=".."[["..v.."]],\n")
      --print("['"..k.."']=".."[["..v.."]]")
      end

   end

 end  --for for lines 

end --end of outline if
outfile:write("['_END_']=[[ENDMARKER]] } \n"..endBlock)
outfile:close()
end



function M.dataset_delete(lib_name,ds_names)
  sas.submit([[
   proc datasets library=@lib_name@;
     delete  @ds_names@;
   run
]],{ds_names=ds_names,lib_name=lib_name},nil,4)
  
end 

return M